package com.fiveplay.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final String TAG = "FivePlay";

    // ---------- CONFIG ----------
    private static final String START_URL = "https://fiveplay.lol/";
    // Main-page navigation outside these hosts is blocked (ad redirects). Add hosts if needed.
    private static final String[] ALLOWED_HOSTS = {"fiveplay.lol"};
    private static final boolean CONTROLS_ENABLED = true;
    // false = native key events (works inside iframes). true = JS KeyboardEvent dispatch.
    // If buttons do nothing in the game, flip this.
    private static final boolean USE_JS_KEYS = false;
    // Joystick: up, left, down, right
    private static final int[] STICK_KEYS = {
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D};
    // Buttons (max 4): bottom, right, left, top
    private static final String[] BTN_LABELS = {"A", "B", "X", "Y"};
    private static final int[] BTN_KEYS = {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_SHIFT_LEFT,
            KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_Q};
    // ----------------------------

    private static final String ERROR_HTML =
            "<html><body style='background:#000;color:#fff;font-family:sans-serif;"
                    + "display:flex;flex-direction:column;align-items:center;"
                    + "justify-content:center;height:100vh;margin:0'>"
                    + "<h2>No connection</h2>"
                    + "<button style='font-size:20px;padding:12px 28px' "
                    + "onclick=\"location.href='" + START_URL + "'\">Retry</button>"
                    + "</body></html>";

    private FrameLayout root;
    private WebView webView;
    private ControlOverlay overlay;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private long lastBackPress = 0L;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        enterImmersive();

        ViewGroup.LayoutParams match = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.setMotionEventSplittingEnabled(true);

        webView = new WebView(this);
        configureWebView(webView);
        root.addView(webView, match);

        if (CONTROLS_ENABLED) {
            overlay = new ControlOverlay(this, this::sendKey, STICK_KEYS, BTN_LABELS, BTN_KEYS);
            root.addView(overlay, match);
        }
        setContentView(root);

        if (state == null || webView.restoreState(state) == null) {
            webView.loadUrl(START_URL);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        // Some sites refuse WebView clients ("; wv" in the user agent): present as plain Chrome.
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));

        w.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        w.setBackgroundColor(0xFF000000);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setLongClickable(false);
        w.setOnLongClickListener(v -> true);
        w.setHapticFeedbackEnabled(false);
        w.setFocusable(true);
        w.setFocusableInTouchMode(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new Client());
        w.setWebChromeClient(chromeClient);
    }

    private final WebChromeClient chromeClient = new WebChromeClient() {
        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCallback = cb;
            root.addView(view, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (overlay != null) {
                overlay.bringToFront();
            }
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) {
                return;
            }
            root.removeView(customView);
            customView = null;
            if (customCallback != null) {
                customCallback.onCustomViewHidden();
                customCallback = null;
            }
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            Log.d(TAG, "console: " + m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
            return true;
        }
    };

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (!r.isForMainFrame()) {
                return false;
            }
            Uri u = r.getUrl();
            String scheme = u.getScheme();
            if (!"http".equals(scheme) && !"https".equals(scheme)) {
                Log.w(TAG, "Blocked non-web scheme: " + u);
                return true;
            }
            if (isAllowedHost(u.getHost())) {
                return false;
            }
            Log.w(TAG, "Blocked redirect: " + u);
            Toast.makeText(MainActivity.this, "Blocked redirect", Toast.LENGTH_SHORT).show();
            return true;
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            v.requestFocus();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError err) {
            if (r.isForMainFrame()) {
                Log.e(TAG, "Load error " + err.getErrorCode() + ": " + err.getDescription());
                v.loadDataWithBaseURL(null, ERROR_HTML, "text/html", "UTF-8", null);
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            Log.e(TAG, "Renderer gone, crashed=" + d.didCrash() + ". Restarting.");
            Intent again = getIntent();
            if (root != null) {
                root.removeView(v);
            }
            v.destroy();
            webView = null;
            finish();
            startActivity(again);
            return true;
        }
    }

    private static boolean isAllowedHost(String host) {
        if (host == null) {
            return false;
        }
        String h = host.toLowerCase(Locale.ROOT);
        for (String a : ALLOWED_HOSTS) {
            if (h.equals(a) || h.endsWith("." + a)) {
                return true;
            }
        }
        return false;
    }

    // ---------- key injection ----------

    private void sendKey(int keyCode, boolean down) {
        WebView w = webView;
        if (w == null) {
            return;
        }
        try {
            if (down && !w.hasFocus()) {
                w.requestFocus();
            }
            if (USE_JS_KEYS) {
                sendJsKey(w, keyCode, down);
            } else {
                long now = SystemClock.uptimeMillis();
                w.dispatchKeyEvent(new KeyEvent(now, now,
                        down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP, keyCode, 0));
            }
        } catch (RuntimeException ex) {
            Log.e(TAG, "sendKey failed for keyCode " + keyCode, ex);
        }
    }

    private void sendJsKey(WebView w, int keyCode, boolean down) {
        String[] info = jsInfo(keyCode);
        if (info == null) {
            Log.w(TAG, "No JS mapping for keyCode " + keyCode);
            return;
        }
        String type = down ? "keydown" : "keyup";
        String js = "(function(){"
                + "var k=" + q(info[0]) + ",c=" + q(info[1]) + ",kc=" + info[2] + ";"
                + "var t=document.activeElement;"
                + "if(!t||t===document.body){t=document.querySelector('canvas')||document;}"
                + "var e=new KeyboardEvent('" + type + "',"
                + "{key:k,code:c,keyCode:kc,which:kc,bubbles:true,cancelable:true});"
                + "try{Object.defineProperty(e,'keyCode',{get:function(){return kc;}});"
                + "Object.defineProperty(e,'which',{get:function(){return kc;}});}catch(x){}"
                + "t.dispatchEvent(e);})();";
        w.evaluateJavascript(js, null);
    }

    private static String q(String s) {
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    /** Returns {key, code, jsKeyCode} or null if unmapped. */
    private static String[] jsInfo(int k) {
        if (k >= KeyEvent.KEYCODE_A && k <= KeyEvent.KEYCODE_Z) {
            int off = k - KeyEvent.KEYCODE_A;
            char c = (char) ('a' + off);
            return new String[]{String.valueOf(c), "Key" + Character.toUpperCase(c),
                    String.valueOf(65 + off)};
        }
        if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) {
            int off = k - KeyEvent.KEYCODE_0;
            return new String[]{String.valueOf(off), "Digit" + off, String.valueOf(48 + off)};
        }
        switch (k) {
            case KeyEvent.KEYCODE_SPACE:
                return new String[]{" ", "Space", "32"};
            case KeyEvent.KEYCODE_ENTER:
                return new String[]{"Enter", "Enter", "13"};
            case KeyEvent.KEYCODE_ESCAPE:
                return new String[]{"Escape", "Escape", "27"};
            case KeyEvent.KEYCODE_TAB:
                return new String[]{"Tab", "Tab", "9"};
            case KeyEvent.KEYCODE_SHIFT_LEFT:
                return new String[]{"Shift", "ShiftLeft", "16"};
            case KeyEvent.KEYCODE_CTRL_LEFT:
                return new String[]{"Control", "ControlLeft", "17"};
            case KeyEvent.KEYCODE_DPAD_LEFT:
                return new String[]{"ArrowLeft", "ArrowLeft", "37"};
            case KeyEvent.KEYCODE_DPAD_UP:
                return new String[]{"ArrowUp", "ArrowUp", "38"};
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                return new String[]{"ArrowRight", "ArrowRight", "39"};
            case KeyEvent.KEYCODE_DPAD_DOWN:
                return new String[]{"ArrowDown", "ArrowDown", "40"};
            default:
                return null;
        }
    }

    // ---------- lifecycle ----------

    @SuppressWarnings("deprecation")
    private void enterImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersive();
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) {
            chromeClient.onHideCustomView();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackPress < 2000L) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (webView != null) {
            webView.saveState(out);
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
