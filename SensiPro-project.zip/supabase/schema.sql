-- SensiPro FF: Supabase schema. Run once in the Supabase SQL editor.
-- Auth: enable Email provider; in Auth settings keep "Confirm email" on and use the OTP email template.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- users
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  display_name text,
  phone_model text,
  selected_game text not null default 'freefire_india'
    check (selected_game in ('freefire_india', 'freefire_max', 'freefire_global')),
  vip_tier text not null default 'free' check (vip_tier in ('free', 'pro', 'elite')),
  vip_expires_at timestamptz,
  coach_tokens int not null default 2,
  streak_count int not null default 1,
  last_streak_claim timestamptz,
  referral_code text unique,
  referred_by text,
  created_at timestamptz not null default now()
);

-- Random 8-char referral code, retried on collision.
create or replace function public.make_referral_code() returns text
language plpgsql as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  code text;
  i int;
begin
  loop
    code := 'SP';
    for i in 1..6 loop
      code := code || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists (select 1 from public.users where referral_code = code);
  end loop;
  return code;
end;
$$;

-- Create the profile row when someone signs up.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.users (id, email, referral_code)
  values (new.id, coalesce(new.email, ''), public.make_referral_code())
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.users enable row level security;

drop policy if exists "users read own" on public.users;
create policy "users read own" on public.users for select using (auth.uid() = id);

-- Users may edit only these harmless columns. vip_tier, tokens and referral fields change only through
-- server functions or the service role.
revoke update on public.users from authenticated;
grant update (display_name, phone_model, selected_game) on public.users to authenticated;
drop policy if exists "users update own" on public.users;
create policy "users update own" on public.users for update using (auth.uid() = id) with check (auth.uid() = id);

-- ----------------------------------------------------- sensitivity_profiles
create table if not exists public.sensitivity_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  profile_name text not null,
  phone_model text not null,
  general int not null,
  red_dot int not null,
  scope_2x int not null,
  scope_4x int not null,
  scope_awm int not null,
  free_look int not null,
  fire_button_size int not null,
  recommended_dpi int not null,
  pointer_speed int not null default 0,
  finger_layout int not null default 3 check (finger_layout in (2, 3, 4)),
  is_favorite boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists sensitivity_profiles_user_idx on public.sensitivity_profiles (user_id);

alter table public.sensitivity_profiles enable row level security;
drop policy if exists "profiles own" on public.sensitivity_profiles;
create policy "profiles own" on public.sensitivity_profiles
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- -------------------------------------------------------- influencer_presets
create table if not exists public.influencer_presets (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  region text not null check (region in ('IN', 'BR', 'GLOBAL')),
  avatar_url text,
  weapon_focus text,
  general int not null,
  red_dot int not null,
  scope_2x int not null,
  scope_4x int not null,
  scope_awm int not null,
  free_look int not null,
  fire_button_size int not null,
  recommended_dpi int not null,
  is_vip_only boolean not null default true,
  confirmed boolean not null default false -- false = estimate, not published by the creator
);

alter table public.influencer_presets enable row level security;
drop policy if exists "presets readable" on public.influencer_presets;
create policy "presets readable" on public.influencer_presets for select using (true);

insert into public.influencer_presets
  (name, region, weapon_focus, general, red_dot, scope_2x, scope_4x, scope_awm, free_look, fire_button_size, recommended_dpi, is_vip_only, confirmed)
values
  ('Total Gaming (AjjuBhai)', 'IN', 'AR / SMG', 96, 92, 88, 82, 72, 60, 48, 540, false, false),
  ('Raistar', 'IN', 'Shotgun / AR', 100, 95, 90, 84, 70, 62, 50, 600, true, false),
  ('Gyan Gaming', 'IN', 'AR', 92, 88, 84, 78, 68, 58, 46, 540, true, false),
  ('Desi Gamers (AmitBhai)', 'IN', 'SMG / AR', 94, 90, 86, 80, 70, 60, 46, 450, true, false),
  ('Pahadi Gaming', 'IN', 'AR / Sniper', 90, 86, 82, 76, 74, 55, 44, 540, true, false),
  ('Nobru', 'BR', 'Rush / Shotgun', 100, 96, 92, 86, 72, 65, 52, 600, true, false),
  ('Cerol', 'BR', 'Shotgun', 98, 94, 90, 84, 70, 62, 50, 600, true, false),
  ('Bak', 'BR', 'SMG / AR', 96, 92, 88, 82, 70, 60, 48, 540, true, false),
  ('Thurzin', 'BR', 'Rush', 100, 95, 90, 85, 72, 64, 52, 600, true, false),
  ('WhiteFF', 'GLOBAL', 'AR / Sniper', 92, 88, 84, 80, 76, 58, 46, 540, true, false),
  ('Syblus', 'GLOBAL', 'SMG', 94, 90, 86, 80, 70, 60, 48, 540, true, false)
on conflict (name) do nothing;

-- ------------------------------------------------------------------ coupons
create table if not exists public.coupons (
  code text primary key,
  tokens int not null check (tokens > 0),
  max_uses int,
  used int not null default 0,
  active boolean not null default true
);
alter table public.coupons enable row level security; -- no policies: only the service role and redeem_code() touch it

create table if not exists public.redemptions (
  user_id uuid not null references public.users(id) on delete cascade,
  code text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, code)
);
alter table public.redemptions enable row level security;
drop policy if exists "redemptions read own" on public.redemptions;
create policy "redemptions read own" on public.redemptions for select using (auth.uid() = user_id);

-- Redeems a creator coupon or a friend's referral code. Returns the Coach Tokens granted.
create or replace function public.redeem_code(p_code text) returns int
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  clean text := upper(trim(p_code));
  c public.coupons%rowtype;
  referrer public.users%rowtype;
  me public.users%rowtype;
begin
  if uid is null then raise exception 'Sign in first.'; end if;
  if clean is null or length(clean) < 4 then raise exception 'Invalid code.'; end if;
  if exists (select 1 from public.redemptions where user_id = uid and code = clean) then
    raise exception 'You already used this code.';
  end if;

  -- 1) creator coupon
  select * into c from public.coupons where code = clean and active for update;
  if found then
    if c.max_uses is not null and c.used >= c.max_uses then raise exception 'This coupon is used up.'; end if;
    update public.coupons set used = used + 1 where code = clean;
    update public.users set coach_tokens = coach_tokens + c.tokens where id = uid;
    insert into public.redemptions (user_id, code) values (uid, clean);
    return c.tokens;
  end if;

  -- 2) friend referral (each account can be referred once, never by itself)
  select * into me from public.users where id = uid for update;
  select * into referrer from public.users where referral_code = clean;
  if not found then raise exception 'Code not found.'; end if;
  if referrer.id = uid then raise exception 'You cannot use your own code.'; end if;
  if me.referred_by is not null then raise exception 'You already joined with a referral code.'; end if;

  update public.users set referred_by = clean, coach_tokens = coach_tokens + 2 where id = uid;
  update public.users set coach_tokens = coach_tokens + 2 where id = referrer.id;
  insert into public.redemptions (user_id, code) values (uid, clean);
  return 2;
end;
$$;

revoke all on function public.redeem_code(text) from public;
grant execute on function public.redeem_code(text) to authenticated;

-- ---------------------------------------------------------- support_tickets
create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  subject text not null check (length(subject) between 3 and 140),
  message text not null check (length(message) between 10 and 4000),
  priority boolean not null default false,
  status text not null default 'open',
  created_at timestamptz not null default now()
);
alter table public.support_tickets enable row level security;
drop policy if exists "tickets insert own" on public.support_tickets;
create policy "tickets insert own" on public.support_tickets for insert with check (auth.uid() = user_id);
drop policy if exists "tickets read own" on public.support_tickets;
create policy "tickets read own" on public.support_tickets for select using (auth.uid() = user_id);

-- Example creator coupon (remove or edit): insert into public.coupons (code, tokens, max_uses) values ('WELCOME5', 5, 100);
