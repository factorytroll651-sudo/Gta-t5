/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './src/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        base: '#05070B',
        card: '#0F141F',
        elevated: '#161D2E',
        line: 'rgba(255,255,255,0.08)',
        neon: { DEFAULT: '#22C55E', light: '#4ADE80' },
        gold: { DEFAULT: '#F59E0B', light: '#FBBF24' },
        crimson: { DEFAULT: '#EF4444', dark: '#DC2626' },
        muted: '#94A3B8',
      },
    },
  },
  plugins: [],
};
