# SensiPro FF: AI Coach & Sensi

Expo SDK 54 · Expo Router · NativeWind · Zustand · ML Kit OCR · RevenueCat · Supabase (optional)

## Phone se APK banana (sirf GitHub, PC nahi chahiye)

1. GitHub par naya repo banao (ya purana use karo).
2. Repo root par ye 2 cheezein upload karo:
   - `SensiPro-project.zip` (zip ko extract mat karo, as-is upload karo)
   - `.github/workflows/build.yml` (file ka path exactly yahi hona chahiye; GitHub app/web mein "Add file → Create new file" mein naam `.github/workflows/build.yml` likh kar content paste karo)
3. Repo → **Actions** tab → **Build SensiPro APK** → **Run workflow**.
4. 15-30 minute baad build khatam hoga. APK **Releases** (right side) ya us run ke **Artifacts** mein milega: `SensiPro-FF.apk`.
5. Phone mein APK install karo (Unknown sources allow karna padega).

Build fail ho to Actions mein red step kholo, last 40 lines copy karke bhej do.

## Workflow input

`dev_unlock` (default `1`): 7 baar Settings ke footer par tap karne se Elite + 500 tokens milte hain. Apne testing APK ke liye `1` rakho. **Public release ya dusron ko dene se pehle `0` karo**, warna koi bhi paywall skip kar lega.

## Optional secrets (Repo → Settings → Secrets and variables → Actions)

| Secret | Kya enable hota hai |
| --- | --- |
| `SUPABASE_URL`, `SUPABASE_ANON_KEY` | Email OTP login, referral/coupon codes, support tickets, profile backup. Pehle `supabase/schema.sql` Supabase SQL editor mein run karo. |
| `RC_ANDROID_KEY` | Real purchases (RevenueCat). Play Console mein ye product IDs banao: `sensipro_tokens_3`, `sensipro_tokens_10`, `sensipro_pro_monthly`, `sensipro_elite_annual`, `sensipro_elite_lifetime`. RevenueCat mein entitlements `pro` aur `elite` banao. |
| `COACH_API_URL` | Clip analysis (server par vision model chahiye). `POST {url}/analyze-clip`, multipart field `clip`, JSON jawab: `headshotAccuracy`, `dragSpeed` (`too_slow`/`ideal`/`too_aggressive`), `headshotRatePrediction`, `checklist[]`. |

Koi secret na ho to app offline mode mein chalta hai: sensitivity, guided Coach IA, rewards, Clone Sensi (Elite), launcher sab kaam karte hain. Online features saaf message dikhate hain, kuch fake nahi karte.

## Notes

- Influencer presets estimates hain (`confirmed: false`), creators ke published numbers nahi. UI mein "Estimate" likha hai.
- Token balance aur streak phone par locally store hote hain. Rooted phone par badle ja sakte hain; pakka enforcement ke liye server chahiye.
- Regedit toggles guided checklists hain; ye phone ya game ki koi setting khud nahi badalte.
- Release APK debug keystore se sign hota hai. Play Store par daalne ke liye apni signing key lagani hogi.
