import { useEffect, useState } from 'react';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';

const allHydrated = (): boolean =>
  useSettingsStore.persist.hasHydrated() &&
  useUserStore.persist.hasHydrated() &&
  useSensiStore.persist.hasHydrated();

/** True once every persisted store has finished loading from AsyncStorage. */
export function useStoresHydrated(): boolean {
  const [ready, setReady] = useState<boolean>(allHydrated);

  useEffect(() => {
    if (ready) return undefined;
    const check = (): void => {
      if (allHydrated()) setReady(true);
    };
    const unsubs = [
      useSettingsStore.persist.onFinishHydration(check),
      useUserStore.persist.onFinishHydration(check),
      useSensiStore.persist.onFinishHydration(check),
    ];
    check();
    return () => unsubs.forEach((u) => u());
  }, [ready]);

  return ready;
}
