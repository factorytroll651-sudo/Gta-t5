import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { Currency } from '@/constants/pricing';
import type { GameVersion } from '@/types';

export type SensiScale = 100 | 200;

interface SettingsState {
  hasOnboarded: boolean;
  game: GameVersion;
  /** Matched DeviceSpec id, or null when the device is unknown. */
  deviceId: string | null;
  deviceLabel: string;
  currency: Currency;
  hapticsEnabled: boolean;
  scale: SensiScale;
  completeOnboarding: (p: { game: GameVersion; deviceId: string | null; deviceLabel: string }) => void;
  setGame: (game: GameVersion) => void;
  setDevice: (deviceId: string | null, deviceLabel: string) => void;
  setCurrency: (currency: Currency) => void;
  setHaptics: (enabled: boolean) => void;
  setScale: (scale: SensiScale) => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      hasOnboarded: false,
      game: 'freefire_india',
      deviceId: null,
      deviceLabel: 'Unknown device',
      currency: 'INR',
      hapticsEnabled: true,
      scale: 100,
      completeOnboarding: ({ game, deviceId, deviceLabel }) =>
        set({ hasOnboarded: true, game, deviceId, deviceLabel }),
      setGame: (game) => set({ game }),
      setDevice: (deviceId, deviceLabel) => set({ deviceId, deviceLabel }),
      setCurrency: (currency) => set({ currency }),
      setHaptics: (hapticsEnabled) => set({ hapticsEnabled }),
      setScale: (scale) => set({ scale }),
    }),
    { name: 'sensipro-settings', storage: createJSONStorage(() => AsyncStorage) },
  ),
);
