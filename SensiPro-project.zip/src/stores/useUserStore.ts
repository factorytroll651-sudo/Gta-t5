import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { TIER_FEATURES } from '@/constants/pricing';
import { ONE_TAP_SHOTGUN } from '@/constants/influencers';
import { todayKey } from '@/services/dates';
import { makeReferralCode, uuid } from '@/services/ids';
import { STREAK_LENGTH, computeClaimState, dailyRemaining } from '@/services/streak';
import type { VipTier } from '@/types';

export type TierSource = 'none' | 'store' | 'dev';

export interface SupportTicket {
  id: string;
  subject: string;
  message: string;
  createdAt: string;
  status: 'queued' | 'sent';
}

export type ClaimResult =
  | { ok: true; day: number; presetUnlocked: boolean }
  | { ok: false; reason: 'already_claimed' };

interface UserState {
  userId: string | null;
  email: string | null;
  vipTier: VipTier;
  tierSource: TierSource;
  coachTokens: number;
  /** Day number (1..7) of the latest daily claim. 0 = never claimed. */
  streakCount: number;
  lastClaimDate: string | null;
  unlockedPresetIds: string[];
  referralCode: string;
  redeemedCodes: string[];
  dailyCoachDate: string | null;
  dailyCoachUsed: number;
  tickets: SupportTicket[];

  setAuth: (userId: string, email: string) => void;
  clearAuth: () => void;
  setVipTier: (tier: VipTier, source: TierSource) => void;
  addTokens: (amount: number) => void;
  /** Spends one token for a clip analysis. Elite is unlimited and spends nothing. */
  spendToken: () => boolean;
  /** Uses one of today's guided Coach IA runs. Returns false when the daily limit is reached. */
  consumeDailyCoach: () => boolean;
  claimDaily: () => ClaimResult;
  unlockPreset: (id: string) => void;
  setReferralCode: (code: string) => void;
  markRedeemed: (code: string) => void;
  addTicket: (subject: string, message: string, status: SupportTicket['status']) => void;
  markTicketsSent: (ids: readonly string[]) => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      userId: null,
      email: null,
      vipTier: 'free',
      tierSource: 'none',
      coachTokens: 2,
      streakCount: 0,
      lastClaimDate: null,
      unlockedPresetIds: [],
      referralCode: makeReferralCode(),
      redeemedCodes: [],
      dailyCoachDate: null,
      dailyCoachUsed: 0,
      tickets: [],

      setAuth: (userId, email) => set({ userId, email }),
      clearAuth: () => set({ userId: null, email: null }),
      setVipTier: (vipTier, tierSource) => set({ vipTier, tierSource }),
      addTokens: (amount) =>
        set((s) => ({ coachTokens: s.coachTokens + Math.max(0, Math.floor(amount)) })),

      spendToken: () => {
        const s = get();
        if (s.vipTier === 'elite') return true;
        if (s.coachTokens <= 0) return false;
        set({ coachTokens: s.coachTokens - 1 });
        return true;
      },

      consumeDailyCoach: () => {
        const s = get();
        const today = todayKey();
        const left = dailyRemaining(
          TIER_FEATURES[s.vipTier].coachPerDay,
          s.dailyCoachDate,
          s.dailyCoachUsed,
          today,
        );
        if (left <= 0) return false;
        const usedToday = s.dailyCoachDate === today ? s.dailyCoachUsed : 0;
        set({ dailyCoachDate: today, dailyCoachUsed: usedToday + 1 });
        return true;
      },

      claimDaily: () => {
        const s = get();
        const today = todayKey();
        const state = computeClaimState(s.lastClaimDate, s.streakCount, today);
        if (state.blocked) return { ok: false, reason: 'already_claimed' };
        const day = state.nextDay;
        const presetUnlocked = day === STREAK_LENGTH;
        set({
          streakCount: day,
          lastClaimDate: today,
          coachTokens: s.coachTokens + 1,
          unlockedPresetIds:
            presetUnlocked && !s.unlockedPresetIds.includes(ONE_TAP_SHOTGUN.id)
              ? [...s.unlockedPresetIds, ONE_TAP_SHOTGUN.id]
              : s.unlockedPresetIds,
        });
        return { ok: true, day, presetUnlocked };
      },

      unlockPreset: (id) =>
        set((s) => (s.unlockedPresetIds.includes(id) ? s : { unlockedPresetIds: [...s.unlockedPresetIds, id] })),
      setReferralCode: (referralCode) => set({ referralCode }),
      markRedeemed: (code) =>
        set((s) => (s.redeemedCodes.includes(code) ? s : { redeemedCodes: [...s.redeemedCodes, code] })),
      addTicket: (subject, message, status) =>
        set((s) => ({
          tickets: [
            { id: uuid(), subject, message, createdAt: new Date().toISOString(), status },
            ...s.tickets,
          ],
        })),
      markTicketsSent: (ids) =>
        set((s) => ({
          tickets: s.tickets.map((t) => (ids.includes(t.id) ? { ...t, status: 'sent' as const } : t)),
        })),
    }),
    { name: 'sensipro-user', storage: createJSONStorage(() => AsyncStorage) },
  ),
);
