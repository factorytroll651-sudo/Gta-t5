import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { uuid } from '@/services/ids';
import type { CoachReport } from '@/services/coachEngine';
import { applyWeaponCategory, clamp, generateSensi } from '@/services/sensiAlgorithm';
import type { ScreenMetrics } from '@/services/sensiAlgorithm';
import { SENSI_KEYS } from '@/types';
import type {
  DeviceSpec,
  FingerLayout,
  HardwareTuning,
  OptimizerId,
  PlayStyle,
  SensiProfile,
  SensiValues,
  WeaponCategory,
} from '@/types';

const DEFAULT_VALUES: SensiValues = {
  general: 88,
  redDot: 84,
  scope2x: 79,
  scope4x: 75,
  scopeAwm: 70,
  freeLook: 57,
};

const DEFAULT_TUNING: HardwareTuning = {
  fireButtonSize: 46,
  recommendedDpi: Platform.OS === 'android' ? 540 : 0,
  pointerSpeed: 0,
  fingerLayout: 3,
};

interface SensiState {
  /** Values before any weapon multiplier. */
  baseValues: SensiValues;
  /** Values shown and used. */
  values: SensiValues;
  tuning: HardwareTuning;
  weapon: WeaponCategory | null;
  playStyle: PlayStyle;
  profiles: SensiProfile[];
  optimizers: Record<OptimizerId, boolean>;

  generate: (device: DeviceSpec | null, screen: ScreenMetrics, max: number) => void;
  setValue: (key: keyof SensiValues, value: number, max: number) => void;
  setTuning: (patch: Partial<HardwareTuning>) => void;
  setPlayStyle: (style: PlayStyle) => void;
  setFingerLayout: (layout: FingerLayout) => void;
  setWeapon: (weapon: WeaponCategory | null, max: number) => void;
  clampAll: (max: number) => void;
  applyCoachReport: (report: CoachReport) => void;
  applyPreset: (values: SensiValues, tuning: Pick<HardwareTuning, 'fireButtonSize' | 'recommendedDpi'>) => void;
  toggleOptimizer: (id: OptimizerId) => void;
  saveProfile: (name: string, phoneModel: string) => SensiProfile;
  loadProfile: (id: string) => void;
  deleteProfile: (id: string) => void;
  toggleFavorite: (id: string) => void;
  mergeProfiles: (incoming: readonly SensiProfile[]) => number;
}

const clampValues = (v: SensiValues, max: number): SensiValues => {
  const out: SensiValues = { ...v };
  for (const key of SENSI_KEYS) out[key] = clamp(Math.round(v[key]), 0, max);
  return out;
};

export const useSensiStore = create<SensiState>()(
  persist(
    (set, get) => ({
      baseValues: DEFAULT_VALUES,
      values: DEFAULT_VALUES,
      tuning: DEFAULT_TUNING,
      weapon: null,
      playStyle: 'rusher',
      profiles: [],
      optimizers: { miraPerfeita: false, semRecuo: false, fastClick: false, fpsBooster: false },

      generate: (device, screen, max) => {
        const s = get();
        const result = generateSensi({
          device,
          screen,
          playStyle: s.playStyle,
          fingerLayout: s.tuning.fingerLayout,
        });
        set({
          baseValues: result.values,
          values: s.weapon ? applyWeaponCategory(result.values, s.weapon, max) : result.values,
          tuning: result.tuning,
        });
      },

      setValue: (key, value, max) => {
        const s = get();
        const next = clamp(Math.round(value), 0, max);
        set({
          values: { ...s.values, [key]: next },
          baseValues: s.weapon ? s.baseValues : { ...s.baseValues, [key]: next },
        });
      },

      setTuning: (patch) => set((s) => ({ tuning: { ...s.tuning, ...patch } })),
      setPlayStyle: (playStyle) => set({ playStyle }),
      setFingerLayout: (fingerLayout) => set((s) => ({ tuning: { ...s.tuning, fingerLayout } })),

      setWeapon: (weapon, max) => {
        const s = get();
        set({
          weapon,
          values: weapon ? applyWeaponCategory(s.baseValues, weapon, max) : s.baseValues,
        });
      },

      clampAll: (max) =>
        set((s) => ({ values: clampValues(s.values, max), baseValues: clampValues(s.baseValues, max) })),

      applyCoachReport: (report) =>
        set({ baseValues: report.values, values: report.values, tuning: report.tuning, weapon: null }),

      applyPreset: (values, tuning) =>
        set((s) => ({
          baseValues: values,
          values,
          weapon: null,
          tuning: {
            ...s.tuning,
            fireButtonSize: tuning.fireButtonSize,
            recommendedDpi: Platform.OS === 'android' ? tuning.recommendedDpi : 0,
          },
        })),

      toggleOptimizer: (id) => set((s) => ({ optimizers: { ...s.optimizers, [id]: !s.optimizers[id] } })),

      saveProfile: (name, phoneModel) => {
        const s = get();
        const profile: SensiProfile = {
          ...s.values,
          ...s.tuning,
          id: uuid(),
          profileName: name,
          phoneModel,
          isFavorite: false,
          createdAt: new Date().toISOString(),
        };
        set({ profiles: [profile, ...s.profiles] });
        return profile;
      },

      loadProfile: (id) => {
        const p = get().profiles.find((x) => x.id === id);
        if (!p) return;
        const values: SensiValues = {
          general: p.general,
          redDot: p.redDot,
          scope2x: p.scope2x,
          scope4x: p.scope4x,
          scopeAwm: p.scopeAwm,
          freeLook: p.freeLook,
        };
        set({
          baseValues: values,
          values,
          weapon: null,
          tuning: {
            fireButtonSize: p.fireButtonSize,
            recommendedDpi: p.recommendedDpi,
            pointerSpeed: p.pointerSpeed,
            fingerLayout: p.fingerLayout,
          },
        });
      },

      deleteProfile: (id) => set((s) => ({ profiles: s.profiles.filter((p) => p.id !== id) })),
      toggleFavorite: (id) =>
        set((s) => ({
          profiles: s.profiles.map((p) => (p.id === id ? { ...p, isFavorite: !p.isFavorite } : p)),
        })),

      mergeProfiles: (incoming) => {
        const known = new Set(get().profiles.map((p) => p.id));
        const fresh = incoming.filter((p) => !known.has(p.id));
        if (fresh.length > 0) set((s) => ({ profiles: [...s.profiles, ...fresh] }));
        return fresh.length;
      },
    }),
    { name: 'sensipro-sensi', storage: createJSONStorage(() => AsyncStorage) },
  ),
);
