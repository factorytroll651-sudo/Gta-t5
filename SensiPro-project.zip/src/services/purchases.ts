import { Platform } from 'react-native';
import Purchases, { PURCHASE_TYPE, type CustomerInfo } from 'react-native-purchases';
import {
  PRODUCT_TIER,
  STORE_PRODUCT_IDS,
  TOKEN_GRANTS,
  type ProductId,
} from '@/constants/pricing';
import type { VipTier } from '@/types';

/** RevenueCat entitlement identifiers. Create these two in the RevenueCat dashboard. */
const ENTITLEMENT_ELITE = 'elite';
const ENTITLEMENT_PRO = 'pro';

let configured = false;

export type PurchaseOutcome =
  | { status: 'success'; tier: VipTier | null; tokens: number }
  | { status: 'cancelled' }
  | { status: 'unavailable'; reason: string }
  | { status: 'error'; message: string };

export function initPurchases(): boolean {
  if (configured) return true;
  const key =
    Platform.OS === 'ios'
      ? process.env.EXPO_PUBLIC_RC_IOS_KEY
      : process.env.EXPO_PUBLIC_RC_ANDROID_KEY;
  if (!key) return false;
  try {
    Purchases.configure({ apiKey: key });
    configured = true;
  } catch {
    configured = false;
  }
  return configured;
}

export function purchasesReady(): boolean {
  return configured;
}

export function tierFromCustomerInfo(info: CustomerInfo): VipTier | null {
  const active = info.entitlements.active;
  if (active[ENTITLEMENT_ELITE]) return 'elite';
  if (active[ENTITLEMENT_PRO]) return 'pro';
  return null;
}

const isSubscription = (id: ProductId): boolean => id === 'pro_monthly' || id === 'elite_annual';

const errorMessage = (e: unknown): string => (e instanceof Error ? e.message : 'Purchase failed.');

const wasCancelled = (e: unknown): boolean =>
  typeof e === 'object' && e !== null && 'userCancelled' in e && (e as { userCancelled?: unknown }).userCancelled === true;

export async function purchaseProduct(id: ProductId): Promise<PurchaseOutcome> {
  if (!configured) {
    return {
      status: 'unavailable',
      reason: 'Store billing is not configured in this build (missing RevenueCat key).',
    };
  }
  try {
    const storeId = STORE_PRODUCT_IDS[id];
    const type = isSubscription(id) ? PURCHASE_TYPE.SUBS : PURCHASE_TYPE.INAPP;
    const products = await Purchases.getProducts([storeId], type);
    if (products.length === 0) {
      return { status: 'unavailable', reason: `Product ${storeId} was not found in the store.` };
    }
    const { customerInfo } = await Purchases.purchaseStoreProduct(products[0]);
    const tier = PRODUCT_TIER[id] ? (tierFromCustomerInfo(customerInfo) ?? PRODUCT_TIER[id] ?? null) : null;
    return { status: 'success', tier, tokens: TOKEN_GRANTS[id] ?? 0 };
  } catch (e) {
    if (wasCancelled(e)) return { status: 'cancelled' };
    return { status: 'error', message: errorMessage(e) };
  }
}

/** Returns the tier the store says is active, or null when none (or store unavailable). */
export async function syncEntitlements(): Promise<VipTier | null> {
  if (!configured) return null;
  try {
    return tierFromCustomerInfo(await Purchases.getCustomerInfo());
  } catch {
    return null;
  }
}

export async function restorePurchases(): Promise<PurchaseOutcome> {
  if (!configured) {
    return { status: 'unavailable', reason: 'Store billing is not configured in this build.' };
  }
  try {
    const info = await Purchases.restorePurchases();
    return { status: 'success', tier: tierFromCustomerInfo(info), tokens: 0 };
  } catch (e) {
    return { status: 'error', message: errorMessage(e) };
  }
}
