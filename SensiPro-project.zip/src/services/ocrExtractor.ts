import TextRecognition from '@react-native-ml-kit/text-recognition';
import type { SensiValues } from '@/types';

type OcrKey = keyof SensiValues | 'dpi' | 'fireButtonSize';

interface Rule {
  key: OcrKey;
  label: string;
  pattern: RegExp;
  min: number;
  max: number;
}

export interface OcrExtraction {
  values: Partial<SensiValues>;
  dpi: number | null;
  fireButtonSize: number | null;
  matchedLabels: string[];
  missingLabels: string[];
}

// Order matters: specific labels first, "general" last.
const RULES: readonly Rule[] = [
  { key: 'redDot', label: 'Red Dot', pattern: /(ponto\s*vermelho|red\s*dot)/i, min: 0, max: 200 },
  { key: 'scope2x', label: '2x Scope', pattern: /\b2\s*[x×](?![a-z0-9])/i, min: 0, max: 200 },
  { key: 'scope4x', label: '4x Scope', pattern: /\b4\s*[x×](?![a-z0-9])/i, min: 0, max: 200 },
  { key: 'scopeAwm', label: 'AWM', pattern: /(\bawm\b|sniper)/i, min: 0, max: 200 },
  { key: 'freeLook', label: 'Free Look', pattern: /(olhadinha|free\s*look)/i, min: 0, max: 200 },
  { key: 'dpi', label: 'DPI', pattern: /\bdpi\b/i, min: 100, max: 1000 },
  {
    key: 'fireButtonSize',
    label: 'Fire Button Size',
    pattern: /(tamanho\s*do\s*bot[aã]o|fire\s*button|button\s*size)/i,
    min: 10,
    max: 100,
  },
  { key: 'general', label: 'General', pattern: /\b(geral|general)\b/i, min: 0, max: 200 },
];

const NUMERIC_ONLY = /^\s*\d{1,4}\s*$/;

function readNumber(text: string): number | null {
  const m = text.match(/\b\d{1,4}\b/);
  return m ? Number(m[0]) : null;
}

export function parseSensiText(lines: readonly string[]): OcrExtraction {
  const values: Partial<SensiValues> = {};
  let dpi: number | null = null;
  let fireButtonSize: number | null = null;
  const matched = new Set<OcrKey>();

  lines.forEach((raw, i) => {
    const line = raw.trim();
    if (!line) return;
    const rule = RULES.find((r) => !matched.has(r.key) && r.pattern.test(line));
    if (!rule) return;

    let n = readNumber(line.replace(rule.pattern, ' '));
    const next = lines[i + 1];
    if (n === null && next !== undefined && NUMERIC_ONLY.test(next)) n = readNumber(next);
    if (n === null || n < rule.min || n > rule.max) return;

    matched.add(rule.key);
    if (rule.key === 'dpi') dpi = n;
    else if (rule.key === 'fireButtonSize') fireButtonSize = n;
    else values[rule.key] = n;
  });

  return {
    values,
    dpi,
    fireButtonSize,
    matchedLabels: RULES.filter((r) => matched.has(r.key)).map((r) => r.label),
    missingLabels: RULES.filter((r) => !matched.has(r.key)).map((r) => r.label),
  };
}

/** Requires a native build; ML Kit does not run in Expo Go. */
export async function extractSensiFromImage(uri: string): Promise<OcrExtraction> {
  const result = await TextRecognition.recognize(uri);
  const lines = result.blocks.flatMap((block) => block.lines.map((line) => line.text));
  return parseSensiText(lines.length > 0 ? lines : result.text.split('\n'));
}
