import { Platform } from 'react-native';
import { WEAPON_CATEGORIES } from '@/constants/weapons';
import { SENSI_KEYS } from '@/types';
import type {
  DeviceSpec,
  DeviceTier,
  FingerLayout,
  HardwareTuning,
  PlayStyle,
  SensiValues,
  WeaponCategory,
} from '@/types';

export interface ScreenMetrics {
  width: number;
  height: number;
  pixelRatio: number;
}

export interface SensiInput {
  device: DeviceSpec | null;
  screen: ScreenMetrics;
  playStyle: PlayStyle;
  fingerLayout: FingerLayout;
}

export interface SensiResult {
  values: SensiValues;
  tuning: HardwareTuning;
  tier: DeviceTier;
}

export const DPI_STEPS: readonly number[] = [392, 450, 540, 600, 720];

export const ALGORITHM_DISCLAIMER =
  'Values are heuristic starting points from screen class, refresh rate, play style and finger layout. Fine-tune them in the training ground.';

export const clamp = (v: number, min: number, max: number): number =>
  Math.min(max, Math.max(min, v));

const TIER_BASE: Record<DeviceTier, number> = { entry: 84, mid: 88, flagship: 92, gaming: 94 };
const TIER_DPI: Record<DeviceTier, number> = { entry: 450, mid: 540, flagship: 600, gaming: 720 };
const TIER_POINTER: Record<DeviceTier, number> = { entry: 0, mid: 1, flagship: 1, gaming: 2 };
const STYLE_ADJUST: Record<PlayStyle, number> = { rusher: 4, support: 0, sniper: -4, igl: -2 };
const LAYOUT_ADJUST: Record<FingerLayout, number> = { 2: 3, 3: 0, 4: -2 };
const LAYOUT_BUTTON: Record<FingerLayout, number> = { 2: 52, 3: 46, 4: 42 };
const SCOPE_RATIO: Record<Exclude<keyof SensiValues, 'general'>, number> = {
  redDot: 0.95,
  scope2x: 0.9,
  scope4x: 0.85,
  scopeAwm: 0.8,
  freeLook: 0.65,
};

export function tierFromScreen(screen: ScreenMetrics): DeviceTier {
  const shortSidePx = Math.min(screen.width, screen.height) * screen.pixelRatio;
  if (shortSidePx < 900) return 'entry';
  if (shortSidePx < 1200) return 'mid';
  return 'flagship';
}

const refreshAdjust = (hz: number): number =>
  hz >= 144 ? 2 : hz >= 120 ? 1 : hz <= 60 ? -2 : 0;

export function generateSensi(input: SensiInput): SensiResult {
  const { device, screen, playStyle, fingerLayout } = input;
  const tier = device?.tier ?? tierFromScreen(screen);
  const hz = device?.refreshHz ?? 60;
  const inches = device?.screenInches ?? null;

  const sizeAdjust = inches === null ? 0 : inches > 6.7 ? -1 : inches < 6.3 ? 1 : 0;
  const buttonAdjust = inches === null ? 0 : inches > 6.7 ? -2 : inches < 6.3 ? 2 : 0;

  const general = clamp(
    Math.round(
      TIER_BASE[tier] +
        refreshAdjust(hz) +
        sizeAdjust +
        STYLE_ADJUST[playStyle] +
        LAYOUT_ADJUST[fingerLayout],
    ),
    40,
    100,
  );
  const scaled = (ratio: number): number => clamp(Math.round(general * ratio), 1, 100);

  const values: SensiValues = {
    general,
    redDot: scaled(SCOPE_RATIO.redDot),
    scope2x: scaled(SCOPE_RATIO.scope2x),
    scope4x: scaled(SCOPE_RATIO.scope4x),
    scopeAwm: scaled(SCOPE_RATIO.scopeAwm),
    freeLook: scaled(SCOPE_RATIO.freeLook),
  };

  const tuning: HardwareTuning = {
    fireButtonSize: clamp(LAYOUT_BUTTON[fingerLayout] + buttonAdjust, 30, 70),
    recommendedDpi: Platform.OS === 'android' ? TIER_DPI[tier] : 0,
    pointerSpeed: clamp(TIER_POINTER[tier] + (playStyle === 'sniper' ? -1 : 0), -3, 3),
    fingerLayout,
  };

  return { values, tuning, tier };
}

export function applyWeaponCategory(
  values: SensiValues,
  category: WeaponCategory,
  max = 100,
): SensiValues {
  const { multipliers } = WEAPON_CATEGORIES[category];
  const out: SensiValues = { ...values };
  for (const key of SENSI_KEYS) {
    out[key] = clamp(Math.round(values[key] * multipliers[key]), 1, max);
  }
  return out;
}

export function stepDpi(current: number, direction: 1 | -1): number {
  const nearest = DPI_STEPS.reduce(
    (best, step, i) => (Math.abs(step - current) < Math.abs(DPI_STEPS[best] - current) ? i : best),
    0,
  );
  return DPI_STEPS[clamp(nearest + direction, 0, DPI_STEPS.length - 1)];
}
