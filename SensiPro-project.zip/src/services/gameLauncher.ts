import { Linking, Platform } from 'react-native';
import * as IntentLauncher from 'expo-intent-launcher';
import type { GameVersion } from '@/types';

export const GAME_PACKAGES: Record<GameVersion, string> = {
  freefire_india: 'com.dts.freefireindia',
  freefire_max: 'com.dts.freefiremax',
  freefire_global: 'com.dts.freefireth',
};

export type LaunchResult = 'launched' | 'store_opened' | 'failed';

async function openStore(pkg: string): Promise<boolean> {
  const targets =
    Platform.OS === 'android'
      ? [`market://details?id=${pkg}`, `https://play.google.com/store/apps/details?id=${pkg}`]
      : ['https://apps.apple.com/search?term=garena%20free%20fire'];
  for (const url of targets) {
    try {
      await Linking.openURL(url);
      return true;
    } catch {
      // try next target
    }
  }
  return false;
}

/** Opens the game if installed, otherwise its store page. */
export async function launchGame(game: GameVersion): Promise<LaunchResult> {
  const pkg = GAME_PACKAGES[game];
  if (Platform.OS === 'android') {
    try {
      await IntentLauncher.openApplication(pkg);
      return 'launched';
    } catch {
      // not installed or blocked: fall through to the store
    }
  }
  return (await openStore(pkg)) ? 'store_opened' : 'failed';
}
