/** Local calendar day as YYYY-MM-DD. */
export function todayKey(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

const parseKey = (key: string): number => {
  const [y, m, d] = key.split('-').map(Number);
  return Date.UTC(y, m - 1, d);
};

/** Whole days from `fromKey` to `toKey`. Negative when `toKey` is earlier. */
export function daysBetween(fromKey: string, toKey: string): number {
  return Math.round((parseKey(toKey) - parseKey(fromKey)) / 86_400_000);
}
