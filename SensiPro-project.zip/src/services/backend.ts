import { supabase } from '@/services/supabase';
import type { GameVersion, SensiProfile } from '@/types';

export class BackendError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'BackendError';
  }
}

function client(): NonNullable<typeof supabase> {
  if (!supabase) throw new BackendError('Online services are not configured in this build.');
  return supabase;
}

export interface SessionUser {
  userId: string;
  email: string;
}

export async function sendOtp(email: string): Promise<void> {
  const { error } = await client().auth.signInWithOtp({
    email,
    options: { shouldCreateUser: true },
  });
  if (error) throw new BackendError(error.message);
}

export async function verifyOtp(email: string, token: string): Promise<SessionUser> {
  const { data, error } = await client().auth.verifyOtp({ email, token, type: 'email' });
  if (error || !data.user) throw new BackendError(error?.message ?? 'Verification failed.');
  return { userId: data.user.id, email: data.user.email ?? email };
}

export async function signOut(): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase.auth.signOut();
  if (error) throw new BackendError(error.message);
}

export async function restoreSession(): Promise<SessionUser | null> {
  if (!supabase) return null;
  const { data } = await supabase.auth.getSession();
  const user = data.session?.user;
  if (!user) return null;
  return { userId: user.id, email: user.email ?? '' };
}

export async function getAccessToken(): Promise<string | null> {
  if (!supabase) return null;
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token ?? null;
}

export async function syncUserMeta(
  userId: string,
  meta: { phoneModel: string; game: GameVersion },
): Promise<void> {
  const { error } = await client()
    .from('users')
    .update({ phone_model: meta.phoneModel, selected_game: meta.game })
    .eq('id', userId);
  if (error) throw new BackendError(error.message);
}

export async function fetchMyReferralCode(userId: string): Promise<string | null> {
  const { data, error } = await client()
    .from('users')
    .select('referral_code')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw new BackendError(error.message);
  const code: unknown = data?.referral_code;
  return typeof code === 'string' && code.length > 0 ? code : null;
}

/** Redeems a creator coupon or a friend's referral code. Returns the Coach Tokens granted. */
export async function redeemCode(code: string): Promise<number> {
  const { data, error } = await client().rpc('redeem_code', { p_code: code.trim().toUpperCase() });
  if (error) throw new BackendError(error.message);
  if (typeof data !== 'number') throw new BackendError('Unexpected response from server.');
  return data;
}

export async function submitTicket(
  userId: string,
  subject: string,
  message: string,
  priority: boolean,
): Promise<void> {
  const { error } = await client()
    .from('support_tickets')
    .insert({ user_id: userId, subject, message, priority });
  if (error) throw new BackendError(error.message);
}

export async function backupProfiles(userId: string, profiles: readonly SensiProfile[]): Promise<number> {
  if (profiles.length === 0) return 0;
  const rows = profiles.map((p) => ({
    id: p.id,
    user_id: userId,
    profile_name: p.profileName,
    phone_model: p.phoneModel,
    general: p.general,
    red_dot: p.redDot,
    scope_2x: p.scope2x,
    scope_4x: p.scope4x,
    scope_awm: p.scopeAwm,
    free_look: p.freeLook,
    fire_button_size: p.fireButtonSize,
    recommended_dpi: p.recommendedDpi,
    pointer_speed: p.pointerSpeed,
    finger_layout: p.fingerLayout,
    is_favorite: p.isFavorite,
    created_at: p.createdAt,
  }));
  const { error } = await client().from('sensitivity_profiles').upsert(rows, { onConflict: 'id' });
  if (error) throw new BackendError(error.message);
  return rows.length;
}

interface ProfileRow {
  id: string;
  profile_name: string;
  phone_model: string;
  general: number;
  red_dot: number;
  scope_2x: number;
  scope_4x: number;
  scope_awm: number;
  free_look: number;
  fire_button_size: number;
  recommended_dpi: number;
  pointer_speed: number | null;
  finger_layout: number | null;
  is_favorite: boolean | null;
  created_at: string;
}

export async function restoreProfiles(userId: string): Promise<SensiProfile[]> {
  const { data, error } = await client()
    .from('sensitivity_profiles')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw new BackendError(error.message);
  const rows = (data ?? []) as ProfileRow[];
  return rows.map((r) => ({
    id: r.id,
    profileName: r.profile_name,
    phoneModel: r.phone_model,
    general: r.general,
    redDot: r.red_dot,
    scope2x: r.scope_2x,
    scope4x: r.scope_4x,
    scopeAwm: r.scope_awm,
    freeLook: r.free_look,
    fireButtonSize: r.fire_button_size,
    recommendedDpi: r.recommended_dpi,
    pointerSpeed: r.pointer_speed ?? 0,
    fingerLayout: r.finger_layout === 2 || r.finger_layout === 4 ? r.finger_layout : 3,
    isFavorite: r.is_favorite ?? false,
    createdAt: r.created_at,
  }));
}
