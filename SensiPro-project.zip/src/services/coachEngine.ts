import { clamp, stepDpi } from '@/services/sensiAlgorithm';
import { SENSI_KEYS } from '@/types';
import type {
  AimProblem,
  FingerLayout,
  GameMode,
  HardwareTuning,
  PlayStyle,
  SensiValues,
} from '@/types';

export interface CoachInput {
  role: PlayStyle;
  mode: GameMode;
  problem: AimProblem;
  values: SensiValues;
  tuning: HardwareTuning;
  maxScale?: 100 | 200;
}

export interface CoachChange {
  label: string;
  from: number;
  to: number;
}

export interface CoachReport {
  headline: string;
  values: SensiValues;
  tuning: HardwareTuning;
  changes: CoachChange[];
  tips: string[];
  clipboardText: string;
}

const LABELS: Record<keyof SensiValues, string> = {
  general: 'Geral',
  redDot: 'Ponto Vermelho',
  scope2x: 'Mira 2x',
  scope4x: 'Mira 4x',
  scopeAwm: 'Mira AWM',
  freeLook: 'Olhadinha',
};

export function formatSensiText(values: SensiValues, tuning: HardwareTuning): string {
  const lines = SENSI_KEYS.map((k) => `${LABELS[k]}: ${values[k]}`);
  lines.push(`Tamanho do Botão: ${tuning.fireButtonSize}%`);
  if (tuning.recommendedDpi > 0) lines.push(`DPI: ${tuning.recommendedDpi}`);
  lines.push(`Velocidade do Ponteiro: ${tuning.pointerSpeed > 0 ? '+' : ''}${tuning.pointerSpeed}`);
  lines.push(`Layout: ${tuning.fingerLayout} dedos`);
  return lines.join('\n');
}

export function buildCoachReport(input: CoachInput): CoachReport {
  const max = input.maxScale ?? 100;
  const adjust = (v: number, percent: number): number =>
    clamp(Math.round(v * (1 + percent / 100)), 1, max);

  const values: SensiValues = { ...input.values };
  const tuning: HardwareTuning = { ...input.tuning };
  const tips: string[] = [];
  let headline: string;

  if (input.problem === 'over_head') {
    const cut = input.role === 'sniper' ? 3 : input.role === 'rusher' ? 5 : 4;
    values.general = adjust(values.general, -cut);
    values.redDot = adjust(values.redDot, -cut);
    tuning.fireButtonSize = clamp(tuning.fireButtonSize + 2, 30, 70);
    headline = `Bullets overshoot the head. General and Red Dot down ${cut}%, fire button +2%.`;
    tips.push('Stop the drag the moment the crosshair reaches head height.');
    tips.push('Test on a stationary dummy at 10 m, then 25 m.');
  } else if (input.problem === 'stuck_chest') {
    values.general = adjust(values.general, 4);
    values.redDot = adjust(values.redDot, 5);
    if (tuning.recommendedDpi > 0) {
      tuning.recommendedDpi = stepDpi(tuning.recommendedDpi, 1);
    } else {
      tuning.fireButtonSize = clamp(tuning.fireButtonSize - 2, 30, 70);
    }
    headline = 'Bullets stick to the chest. General +4%, Red Dot +5%, then one step more drag range.';
    tips.push('Start dragging up as you press fire, not after the first bullet lands.');
    tips.push('After a DPI change, confirm the HUD still fits your layout.');
  } else {
    tuning.pointerSpeed = clamp(tuning.pointerSpeed - 1, -3, 3);
    values.general = adjust(values.general, -2);
    const nextLayout: FingerLayout = tuning.fingerLayout === 2 ? 3 : 4;
    tuning.fingerLayout = nextLayout;
    headline = `Horizontal shake. Pointer speed -1, General -2%, move to a ${nextLayout}-finger layout.`;
    tips.push('Keep the aiming thumb planted near the fire button instead of lifting between bursts.');
    tips.push('A thick screen protector or damp thumb makes drag jitter worse.');
  }

  if (input.mode === 'custom_1v1') {
    values.redDot = adjust(values.redDot, 2);
    tips.push('1v1 rooms reward a fast first flick: Red Dot raised 2%.');
  } else if (input.mode === 'contra_squad') {
    values.general = adjust(values.general, 1);
    tips.push('Contra Squad fights are close range: General raised 1%.');
  }

  const changes: CoachChange[] = [];
  for (const key of SENSI_KEYS) {
    if (values[key] !== input.values[key]) {
      changes.push({ label: LABELS[key], from: input.values[key], to: values[key] });
    }
  }
  if (tuning.fireButtonSize !== input.tuning.fireButtonSize) {
    changes.push({ label: 'Tamanho do Botão (%)', from: input.tuning.fireButtonSize, to: tuning.fireButtonSize });
  }
  if (tuning.recommendedDpi !== input.tuning.recommendedDpi) {
    changes.push({ label: 'DPI', from: input.tuning.recommendedDpi, to: tuning.recommendedDpi });
  }
  if (tuning.pointerSpeed !== input.tuning.pointerSpeed) {
    changes.push({ label: 'Velocidade do Ponteiro', from: input.tuning.pointerSpeed, to: tuning.pointerSpeed });
  }
  if (tuning.fingerLayout !== input.tuning.fingerLayout) {
    changes.push({ label: 'Layout (dedos)', from: input.tuning.fingerLayout, to: tuning.fingerLayout });
  }

  return { headline, values, tuning, changes, tips, clipboardText: formatSensiText(values, tuning) };
}

/* ---------- Mode 2: clip / screenshot analysis (server-backed) ---------- */

export type DragSpeed = 'too_slow' | 'ideal' | 'too_aggressive';

export interface ClipAnalysis {
  headshotAccuracy: number;
  dragSpeed: DragSpeed;
  headshotRatePrediction: number;
  checklist: string[];
}

export type CoachApiErrorCode = 'not_configured' | 'network' | 'rejected' | 'bad_response';

export class CoachApiError extends Error {
  readonly code: CoachApiErrorCode;
  constructor(message: string, code: CoachApiErrorCode) {
    super(message);
    this.name = 'CoachApiError';
    this.code = code;
  }
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null;

export function parseClipAnalysis(json: unknown): ClipAnalysis {
  if (!isRecord(json)) throw new CoachApiError('Malformed analysis payload.', 'bad_response');
  const { headshotAccuracy, dragSpeed, headshotRatePrediction, checklist } = json;
  const speeds: readonly DragSpeed[] = ['too_slow', 'ideal', 'too_aggressive'];
  const speed = speeds.find((s) => s === dragSpeed);
  if (
    typeof headshotAccuracy !== 'number' ||
    typeof headshotRatePrediction !== 'number' ||
    !speed ||
    !Array.isArray(checklist)
  ) {
    throw new CoachApiError('Analysis payload is missing required fields.', 'bad_response');
  }
  return {
    headshotAccuracy: clamp(Math.round(headshotAccuracy), 0, 100),
    dragSpeed: speed,
    headshotRatePrediction: clamp(Math.round(headshotRatePrediction), 0, 100),
    checklist: checklist.filter((c): c is string => typeof c === 'string'),
  };
}

export async function analyzeClip(
  media: { uri: string; mimeType: string },
  authToken: string | null,
  signal?: AbortSignal,
): Promise<ClipAnalysis> {
  const base = process.env.EXPO_PUBLIC_COACH_API_URL;
  if (!base) {
    throw new CoachApiError('Coach API is not configured (EXPO_PUBLIC_COACH_API_URL).', 'not_configured');
  }
  const ext = media.mimeType.split('/')[1] ?? 'bin';
  const form = new FormData();
  form.append('clip', { uri: media.uri, name: `clip.${ext}`, type: media.mimeType } as unknown as Blob);

  let res: Response;
  try {
    res = await fetch(`${base.replace(/\/$/, '')}/analyze-clip`, {
      method: 'POST',
      headers: authToken ? { Authorization: `Bearer ${authToken}` } : undefined,
      body: form,
      signal,
    });
  } catch {
    throw new CoachApiError('Could not reach the Coach API.', 'network');
  }
  if (!res.ok) throw new CoachApiError(`Coach API responded ${res.status}.`, 'rejected');
  const json: unknown = await res.json().catch(() => null);
  return parseClipAnalysis(json);
}
