import { Dimensions, PixelRatio } from 'react-native';
import * as Device from 'expo-device';
import { DEVICES, matchDetectedDevice } from '@/constants/devices';
import type { ScreenMetrics } from '@/services/sensiAlgorithm';
import type { DeviceSpec } from '@/types';

export interface DetectedDevice {
  label: string;
  match: DeviceSpec | null;
}

export function getScreenMetrics(): ScreenMetrics {
  const { width, height } = Dimensions.get('window');
  return { width, height, pixelRatio: PixelRatio.get() };
}

export function detectDevice(): DetectedDevice {
  const brand = Device.brand ?? '';
  const model = Device.modelName ?? '';
  const label = [brand, model].filter((s) => s.length > 0).join(' ') || 'Unknown device';
  const match = matchDetectedDevice(`${brand} ${model}`) ?? matchDetectedDevice(model);
  return { label, match };
}

export function findDevice(deviceId: string | null): DeviceSpec | null {
  if (!deviceId) return null;
  return DEVICES.find((d) => d.id === deviceId) ?? null;
}
