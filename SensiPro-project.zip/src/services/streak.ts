import { daysBetween, todayKey } from '@/services/dates';

export const STREAK_LENGTH = 7;

export interface ClaimState {
  /** True when nothing can be claimed right now (already claimed today, or the clock moved backwards). */
  blocked: boolean;
  /** Day number (1..7) that the next successful claim will award. */
  nextDay: number;
}

/**
 * `streak` is the day number (1..7) of the most recent claim.
 * Claiming on consecutive days advances it; after day 7 a new cycle starts at day 1;
 * missing a day resets to day 1.
 */
export function computeClaimState(
  lastClaimDate: string | null,
  streak: number,
  today: string = todayKey(),
): ClaimState {
  if (!lastClaimDate) return { blocked: false, nextDay: 1 };
  const gap = daysBetween(lastClaimDate, today);
  const advanced = streak >= STREAK_LENGTH ? 1 : streak + 1;
  if (gap <= 0) return { blocked: true, nextDay: advanced };
  if (gap === 1) return { blocked: false, nextDay: advanced };
  return { blocked: false, nextDay: 1 };
}

/** Daily Coach IA uses left. Infinity for unlimited tiers. */
export function dailyRemaining(
  limit: number,
  usedDate: string | null,
  used: number,
  today: string = todayKey(),
): number {
  if (!Number.isFinite(limit)) return Number.POSITIVE_INFINITY;
  const usedToday = usedDate === today ? used : 0;
  return Math.max(0, limit - usedToday);
}
