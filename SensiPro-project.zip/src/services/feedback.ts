import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/stores/useSettingsStore';

const enabled = (): boolean => useSettingsStore.getState().hapticsEnabled;

const swallow = (): void => {
  // Haptics can be unavailable on some devices. Never let that break a tap.
};

export function selectionTick(): void {
  if (enabled()) Haptics.selectionAsync().catch(swallow);
}

export function tapFeedback(): void {
  if (enabled()) Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(swallow);
}

export function successFeedback(): void {
  if (enabled()) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(swallow);
}

export function warnFeedback(): void {
  if (enabled()) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(swallow);
}
