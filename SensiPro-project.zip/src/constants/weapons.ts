import type { SensiValues, WeaponCategory } from '@/types';

export type SensiMultipliers = Record<keyof SensiValues, number>;

export interface WeaponCategoryDef {
  id: WeaponCategory;
  label: string;
  weapons: readonly string[];
  multipliers: SensiMultipliers;
  dragNote: string;
}

export const WEAPON_CATEGORIES: Record<WeaponCategory, WeaponCategoryDef> = {
  shotgun: {
    id: 'shotgun',
    label: 'Shotguns / Doze',
    weapons: ['M1014', 'MAG-7', 'SPAS-12', 'M1887 / Two9'],
    multipliers: { general: 1.06, redDot: 1.08, scope2x: 1, scope4x: 1, scopeAwm: 1, freeLook: 1 },
    dragNote: 'Short, fast upward flick. Commit to the drag, do not feather it.',
  },
  smg: {
    id: 'smg',
    label: 'SMGs',
    weapons: ['MP40', 'UMP', 'Thompson', 'MP5'],
    multipliers: { general: 1.04, redDot: 1.05, scope2x: 1.02, scope4x: 0.98, scopeAwm: 0.98, freeLook: 1 },
    dragNote: 'Continuous, steady drag through the whole spray.',
  },
  rifle: {
    id: 'rifle',
    label: 'Rifles / ARs',
    weapons: ['AK-47', 'SCAR', 'M4A1', 'Groza', 'Woodpecker'],
    multipliers: { general: 1, redDot: 1, scope2x: 1, scope4x: 1.02, scopeAwm: 1, freeLook: 1 },
    dragNote: 'Pull down against recoil in a curve, easing off after the first 8 bullets.',
  },
  sniper: {
    id: 'sniper',
    label: 'Snipers',
    weapons: ['AWM', 'M82B', 'Kar98k'],
    multipliers: { general: 0.96, redDot: 0.95, scope2x: 0.97, scope4x: 0.98, scopeAwm: 1.04, freeLook: 1 },
    dragNote: 'Micro-flicks only. Scope, settle, then fire.',
  },
};

export const WEAPON_CATEGORY_LIST: readonly WeaponCategoryDef[] = Object.values(WEAPON_CATEGORIES);
