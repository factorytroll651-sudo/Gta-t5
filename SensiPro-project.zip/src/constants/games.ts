import type { GameVersion } from '@/types';

export const GAME_LIST: readonly GameVersion[] = ['freefire_india', 'freefire_max', 'freefire_global'];

export const GAME_LABELS: Record<GameVersion, string> = {
  freefire_india: 'Free Fire India',
  freefire_max: 'Free Fire MAX',
  freefire_global: 'Free Fire Global',
};

export const GAME_BLURB: Record<GameVersion, string> = {
  freefire_india: 'com.dts.freefireindia',
  freefire_max: 'com.dts.freefiremax',
  freefire_global: 'com.dts.freefireth',
};
