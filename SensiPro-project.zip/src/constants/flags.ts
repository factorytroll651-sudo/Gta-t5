/**
 * The 7-tap Elite unlock in Settings only works when this is true.
 * On in dev builds; in release builds only if EXPO_PUBLIC_ENABLE_DEV_UNLOCK=1 at build time.
 */
export const ENABLE_DEV_UNLOCK: boolean =
  __DEV__ || process.env.EXPO_PUBLIC_ENABLE_DEV_UNLOCK === '1';
