import type { DeviceSpec, DeviceTier } from '@/types';

const d = (
  brand: string,
  model: string,
  screenInches: number,
  refreshHz: number,
  tier: DeviceTier,
): DeviceSpec => ({
  id: model.toLowerCase().replace(/\+/g, 'plus').replace(/[^a-z0-9]+/g, '-'),
  brand,
  model,
  screenInches,
  refreshHz,
  tier,
});

export const DEVICES: readonly DeviceSpec[] = [
  d('Redmi', 'Redmi 12', 6.79, 90, 'entry'),
  d('Redmi', 'Redmi Note 13 Pro', 6.67, 120, 'mid'),
  d('Redmi', 'Redmi Note 13 Pro+', 6.67, 120, 'mid'),
  d('POCO', 'POCO X6 Pro', 6.67, 120, 'mid'),
  d('POCO', 'POCO F5', 6.67, 120, 'flagship'),
  d('POCO', 'POCO M6 Pro', 6.79, 90, 'entry'),
  d('Xiaomi', 'Xiaomi 14', 6.36, 120, 'flagship'),
  d('Realme', 'Realme 12 Pro+', 6.7, 120, 'mid'),
  d('Realme', 'Realme Narzo 70', 6.67, 120, 'entry'),
  d('Realme', 'Realme GT 6T', 6.78, 120, 'flagship'),
  d('Realme', 'Realme C55', 6.72, 90, 'entry'),
  d('Vivo', 'Vivo V30', 6.78, 120, 'mid'),
  d('Vivo', 'Vivo T3', 6.67, 120, 'mid'),
  d('Vivo', 'Vivo Y200', 6.67, 120, 'entry'),
  d('iQOO', 'iQOO Neo 9 Pro', 6.78, 144, 'flagship'),
  d('iQOO', 'iQOO Z9', 6.67, 120, 'mid'),
  d('iQOO', 'iQOO 12', 6.78, 144, 'gaming'),
  d('OnePlus', 'OnePlus 12R', 6.78, 120, 'flagship'),
  d('OnePlus', 'OnePlus Nord CE 4', 6.7, 120, 'mid'),
  d('OnePlus', 'OnePlus 12', 6.82, 120, 'flagship'),
  d('Samsung', 'Galaxy S24', 6.2, 120, 'flagship'),
  d('Samsung', 'Galaxy A55', 6.6, 120, 'mid'),
  d('Samsung', 'Galaxy M34', 6.5, 120, 'mid'),
  d('Samsung', 'Galaxy F54', 6.7, 120, 'mid'),
  d('Samsung', 'Galaxy A15', 6.5, 90, 'entry'),
  d('Apple', 'iPhone 11', 6.1, 60, 'mid'),
  d('Apple', 'iPhone 12', 6.1, 60, 'flagship'),
  d('Apple', 'iPhone 13', 6.1, 60, 'flagship'),
  d('Apple', 'iPhone 14', 6.1, 60, 'flagship'),
  d('Apple', 'iPhone 15', 6.1, 60, 'flagship'),
  d('Apple', 'iPhone 15 Pro Max', 6.7, 120, 'flagship'),
  d('Apple', 'iPhone 16 Pro Max', 6.9, 120, 'flagship'),
  d('ASUS', 'ASUS ROG Phone 8', 6.78, 165, 'gaming'),
  d('Black Shark', 'Black Shark 5 Pro', 6.67, 144, 'gaming'),
  d('Infinix', 'Infinix Note 40 Pro', 6.78, 120, 'mid'),
  d('Infinix', 'Infinix Hot 40', 6.78, 120, 'entry'),
];

const norm = (s: string): string =>
  s.toLowerCase().replace(/\+/g, 'plus').replace(/[^a-z0-9]/g, '');

/** Best-effort match against expo-device strings. Longest model name wins. */
export function matchDetectedDevice(modelName: string | null): DeviceSpec | null {
  if (!modelName) return null;
  const haystack = norm(modelName);
  const hits = DEVICES.filter((dev) => haystack.includes(norm(dev.model)));
  hits.sort((a, b) => b.model.length - a.model.length);
  return hits[0] ?? null;
}

export function searchDevices(query: string, limit = 20): DeviceSpec[] {
  const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
  if (tokens.length === 0) return DEVICES.slice(0, limit);
  return DEVICES.filter((dev) => {
    const hay = `${dev.brand} ${dev.model}`.toLowerCase();
    return tokens.every((t) => hay.includes(t));
  }).slice(0, limit);
}
