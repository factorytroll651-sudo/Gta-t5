import type { SensiValues } from '@/types';

export type CreatorRegion = 'IN' | 'BR' | 'GLOBAL';

export interface InfluencerPreset extends SensiValues {
  id: string;
  name: string;
  region: CreatorRegion;
  weaponFocus: string;
  fireButtonSize: number;
  recommendedDpi: number;
  isVipOnly: boolean;
  /** false = estimate, not published by the creator. UI must label these "Estimate". */
  confirmed: boolean;
}

type Six = readonly [number, number, number, number, number, number];

const p = (
  id: string,
  name: string,
  region: CreatorRegion,
  weaponFocus: string,
  v: Six,
  fireButtonSize: number,
  recommendedDpi: number,
  isVipOnly = true,
): InfluencerPreset => ({
  id,
  name,
  region,
  weaponFocus,
  general: v[0],
  redDot: v[1],
  scope2x: v[2],
  scope4x: v[3],
  scopeAwm: v[4],
  freeLook: v[5],
  fireButtonSize,
  recommendedDpi,
  isVipOnly,
  confirmed: false,
});

export const INFLUENCER_PRESETS: readonly InfluencerPreset[] = [
  p('total-gaming', 'Total Gaming (AjjuBhai)', 'IN', 'AR / SMG', [96, 92, 88, 82, 72, 60], 48, 540, false),
  p('raistar', 'Raistar', 'IN', 'Shotgun / AR', [100, 95, 90, 84, 70, 62], 50, 600),
  p('gyan-gaming', 'Gyan Gaming', 'IN', 'AR', [92, 88, 84, 78, 68, 58], 46, 540),
  p('desi-gamers', 'Desi Gamers (AmitBhai)', 'IN', 'SMG / AR', [94, 90, 86, 80, 70, 60], 46, 450),
  p('pahadi-gaming', 'Pahadi Gaming', 'IN', 'AR / Sniper', [90, 86, 82, 76, 74, 55], 44, 540),
  p('nobru', 'Nobru', 'BR', 'Rush / Shotgun', [100, 96, 92, 86, 72, 65], 52, 600),
  p('cerol', 'Cerol', 'BR', 'Shotgun', [98, 94, 90, 84, 70, 62], 50, 600),
  p('bak', 'Bak', 'BR', 'SMG / AR', [96, 92, 88, 82, 70, 60], 48, 540),
  p('thurzin', 'Thurzin', 'BR', 'Rush', [100, 95, 90, 85, 72, 64], 52, 600),
  p('whiteff', 'WhiteFF', 'GLOBAL', 'AR / Sniper', [92, 88, 84, 80, 76, 58], 46, 540),
  p('syblus', 'Syblus', 'GLOBAL', 'SMG', [94, 90, 86, 80, 70, 60], 48, 540),
];

/** Day-7 streak reward. An app preset, not tied to any creator. */
export const ONE_TAP_SHOTGUN: InfluencerPreset = {
  id: 'one-tap-shotgun',
  name: 'One-Tap Shotgun',
  region: 'GLOBAL',
  weaponFocus: 'Shotgun',
  general: 100,
  redDot: 98,
  scope2x: 90,
  scope4x: 84,
  scopeAwm: 72,
  freeLook: 62,
  fireButtonSize: 52,
  recommendedDpi: 600,
  isVipOnly: false,
  confirmed: false,
};
