import type { OptimizerId } from '@/types';

export interface OptimizerDef {
  id: OptimizerId;
  title: string;
  subtitle: string;
  steps: readonly string[];
}

/** These are guided checklists. The app does not change any system or game setting. */
export const OPTIMIZERS: readonly OptimizerDef[] = [
  {
    id: 'miraPerfeita',
    title: 'Mira Perfeita',
    subtitle: 'Aim stabilization profile for less crosshair jitter',
    steps: [
      'Keep General at or below the generated value. If the crosshair trembles, lower Red Dot by 2-3.',
      'Set Pointer Speed one notch lower than recommended.',
      'Clean the screen and remove thick protectors that drag.',
      'Rest the aiming thumb flat and drag with the pad, not the tip.',
    ],
  },
  {
    id: 'semRecuo',
    title: 'Sem Recuo',
    subtitle: 'Recoil guide: drag-up angle by target distance',
    steps: [
      'Press fire and start the drag in the same motion.',
      'Follow the angle in the guide for your target distance.',
      'Ease the drag after the first 8 bullets with rifles.',
      'Test on the training ground dummy at 10 m and 25 m.',
    ],
  },
  {
    id: 'fastClick',
    title: 'Fast Click',
    subtitle: 'Touch response calibration checklist',
    steps: [
      'Developer options: turn on Pointer location and check the trail is smooth.',
      'Turn off edge-swipe or gesture features that delay touches.',
      'Disable battery saver. Use Game Mode or high performance if your phone has it.',
      'Raise Pointer Speed one notch if taps register late.',
    ],
  },
  {
    id: 'fpsBooster',
    title: 'Redutor de Lag / FPS Booster',
    subtitle: 'Memory flush and background cache checklist',
    steps: [
      'Close all recent apps before launching the game.',
      'Clear the cache of heavy background apps in system settings.',
      'Turn on Do Not Disturb and disable battery saver.',
      'Lower in-game graphics to Smooth if the frame rate drops.',
      'Keep 3-4 GB of storage free.',
    ],
  },
];
