import type { VipTier } from '@/types';

export type Currency = 'INR' | 'USD' | 'BRL';
export type ProductId = 'tokens_3' | 'tokens_10' | 'pro_monthly' | 'elite_annual' | 'elite_lifetime';

export const CURRENCIES: readonly Currency[] = ['INR', 'USD', 'BRL'];

/** Product identifiers to create in Google Play Console / RevenueCat. */
export const STORE_PRODUCT_IDS: Record<ProductId, string> = {
  tokens_3: 'sensipro_tokens_3',
  tokens_10: 'sensipro_tokens_10',
  pro_monthly: 'sensipro_pro_monthly',
  elite_annual: 'sensipro_elite_annual',
  elite_lifetime: 'sensipro_elite_lifetime',
};

export const PRODUCT_TITLES: Record<ProductId, string> = {
  tokens_3: '3 Coach Tokens',
  tokens_10: '10 Coach Tokens',
  pro_monthly: 'Pro Monthly',
  elite_annual: 'Elite Annual',
  elite_lifetime: 'Elite Lifetime',
};

/** List prices shown in the UI. The store's checkout shows the final charged amount. */
export const PRICES: Record<Currency, Partial<Record<ProductId, string>>> = {
  INR: {
    tokens_3: '₹29',
    tokens_10: '₹79',
    pro_monthly: '₹99/month',
    elite_annual: '₹299/year',
    elite_lifetime: '₹499 one-time',
  },
  USD: {
    tokens_3: '$0.99',
    pro_monthly: '$2.99/month',
    elite_annual: '$9.99/year',
  },
  BRL: {
    tokens_3: 'R$ 4,90',
    pro_monthly: 'R$ 14,90/mês',
    elite_annual: 'R$ 49,90/ano',
  },
};

export const TOKEN_GRANTS: Partial<Record<ProductId, number>> = { tokens_3: 3, tokens_10: 10 };

export const PRODUCT_TIER: Partial<Record<ProductId, VipTier>> = {
  pro_monthly: 'pro',
  elite_annual: 'elite',
  elite_lifetime: 'elite',
};

export interface TierFeatures {
  label: string;
  /** Free Coach IA uses per day. Infinity = unlimited. */
  coachPerDay: number;
  weaponPresets: boolean;
  regedit: boolean;
  cloneSensi: boolean;
  allCreators: boolean;
  prioritySupport: boolean;
  perks: readonly string[];
}

export const TIER_FEATURES: Record<VipTier, TierFeatures> = {
  free: {
    label: 'Free',
    coachPerDay: 1,
    weaponPresets: false,
    regedit: false,
    cloneSensi: false,
    allCreators: false,
    prioritySupport: false,
    perks: [
      'Device-based sensitivity engine',
      'Default device configs',
      '1 Coach IA question per day',
      '1 unlocked creator preset',
    ],
  },
  pro: {
    label: 'Pro',
    coachPerDay: 5,
    weaponPresets: true,
    regedit: true,
    cloneSensi: false,
    allCreators: false,
    prioritySupport: false,
    perks: [
      'Everything in Free',
      'All weapon-specific sensitivities',
      'Regedit optimizer toggles',
      '5 Coach IA uses per day',
    ],
  },
  elite: {
    label: 'Elite',
    coachPerDay: Number.POSITIVE_INFINITY,
    weaponPresets: true,
    regedit: true,
    cloneSensi: true,
    allCreators: true,
    prioritySupport: true,
    perks: [
      'Everything in Pro',
      'Unlimited Coach IA',
      'Clone Sensi OCR scanner',
      'All Indian and global creator presets',
      'Priority support',
    ],
  },
};

export const TIER_ORDER: readonly VipTier[] = ['free', 'pro', 'elite'];
