import { Alert, Pressable, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '@/constants/theme';
import { GAME_LABELS, GAME_LIST } from '@/constants/games';
import { launchGame } from '@/services/gameLauncher';
import { tapFeedback } from '@/services/feedback';
import { useSettingsStore } from '@/stores/useSettingsStore';
import type { GameVersion } from '@/types';

export function LaunchBar() {
  const selected = useSettingsStore((s) => s.game);

  const onLaunch = async (game: GameVersion): Promise<void> => {
    tapFeedback();
    const result = await launchGame(game);
    if (result === 'store_opened') {
      Alert.alert(`${GAME_LABELS[game]} not found`, 'It does not look installed, so its store page was opened.');
    } else if (result === 'failed') {
      Alert.alert('Could not open', `${GAME_LABELS[game]} and its store page could not be opened.`);
    }
  };

  return (
    <View style={{ flexDirection: 'row', gap: 8 }}>
      {GAME_LIST.map((game) => {
        const active = game === selected;
        return (
          <Pressable
            key={game}
            onPress={() => void onLaunch(game)}
            style={({ pressed }) => ({
              flex: 1,
              opacity: pressed ? 0.8 : 1,
              backgroundColor: active ? 'rgba(34,197,94,0.15)' : COLORS.elevated,
              borderWidth: 1,
              borderColor: active ? COLORS.green : COLORS.border,
              borderRadius: 12,
              paddingVertical: 10,
              alignItems: 'center',
              gap: 4,
            })}
          >
            <MaterialCommunityIcons name="rocket-launch" size={20} color={active ? COLORS.greenLight : COLORS.muted} />
            <Text style={{ color: COLORS.text, fontSize: 11, fontWeight: '800', textAlign: 'center' }}>
              {GAME_LABELS[game].replace('Free Fire ', '')}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
