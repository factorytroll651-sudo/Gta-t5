import { useRef, type ComponentProps, type ReactNode } from 'react';
import {
  ActivityIndicator,
  PanResponder,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
  type LayoutChangeEvent,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { COLORS } from '@/constants/theme';
import { TIER_FEATURES } from '@/constants/pricing';
import { selectionTick, tapFeedback } from '@/services/feedback';
import type { FingerLayout, VipTier, WeaponCategory } from '@/types';

export type IconName = ComponentProps<typeof MaterialCommunityIcons>['name'];

const pct = (n: number): `${number}%` => `${n}%` as `${number}%`;
const clampNum = (v: number, min: number, max: number): number => Math.min(max, Math.max(min, v));

/* ------------------------------ layout ------------------------------ */

export function Screen({
  children,
  scroll = true,
  bottomInset = false,
}: {
  children: ReactNode;
  scroll?: boolean;
  bottomInset?: boolean;
}) {
  return (
    <SafeAreaView
      edges={bottomInset ? ['top', 'bottom'] : ['top']}
      style={{ flex: 1, backgroundColor: COLORS.bg }}
    >
      {scroll ? (
        <ScrollView
          contentContainerStyle={{ padding: 16, paddingBottom: 32, gap: 14 }}
          keyboardShouldPersistTaps="handled"
        >
          {children}
        </ScrollView>
      ) : (
        <View style={{ flex: 1, padding: 16, gap: 14 }}>{children}</View>
      )}
    </SafeAreaView>
  );
}

export function ScreenHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <View style={{ gap: 4 }}>
      <Pressable
        onPress={() => {
          tapFeedback();
          if (router.canGoBack()) router.back();
          else router.replace('/(tabs)');
        }}
        hitSlop={10}
        style={{ flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start' }}
      >
        <MaterialCommunityIcons name="chevron-left" size={24} color={COLORS.muted} />
        <Text style={{ color: COLORS.muted, fontWeight: '700' }}>Back</Text>
      </Pressable>
      <Title>{title}</Title>
      {subtitle ? <Text className="text-muted text-sm">{subtitle}</Text> : null}
    </View>
  );
}

export function Card({
  children,
  tone = 'default',
  style,
}: {
  children: ReactNode;
  tone?: 'default' | 'elevated' | 'gold' | 'green';
  style?: ViewStyle;
}) {
  const border =
    tone === 'gold' ? 'rgba(245,158,11,0.55)' : tone === 'green' ? 'rgba(34,197,94,0.5)' : COLORS.border;
  return (
    <View
      style={[
        {
          backgroundColor: tone === 'elevated' ? COLORS.elevated : COLORS.card,
          borderWidth: 1,
          borderColor: border,
          borderRadius: 16,
          padding: 14,
          gap: 10,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function Title({ children }: { children: ReactNode }) {
  return <Text className="text-white text-2xl font-black uppercase tracking-widest">{children}</Text>;
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <Text className="text-muted text-xs font-bold uppercase tracking-widest">{children}</Text>;
}

export function Row({ children, gap = 8 }: { children: ReactNode; gap?: number }) {
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap, flexWrap: 'wrap' }}>{children}</View>;
}

/* ------------------------------ controls ------------------------------ */

type ButtonVariant = 'green' | 'gold' | 'red' | 'dark';

const VARIANT_BG: Record<ButtonVariant, string> = {
  green: COLORS.green,
  gold: COLORS.amber,
  red: COLORS.red,
  dark: COLORS.elevated,
};

export function NeonButton({
  title,
  onPress,
  variant = 'green',
  icon,
  disabled = false,
  loading = false,
  compact = false,
}: {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  icon?: IconName;
  disabled?: boolean;
  loading?: boolean;
  compact?: boolean;
}) {
  const fg = variant === 'dark' ? COLORS.text : '#05070B';
  return (
    <Pressable
      disabled={disabled || loading}
      onPress={() => {
        tapFeedback();
        onPress();
      }}
      style={({ pressed }) => ({
        backgroundColor: VARIANT_BG[variant],
        opacity: disabled ? 0.4 : pressed ? 0.85 : 1,
        borderRadius: 12,
        paddingVertical: compact ? 8 : 13,
        paddingHorizontal: compact ? 12 : 16,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        borderWidth: variant === 'dark' ? 1 : 0,
        borderColor: COLORS.border,
      })}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : icon ? (
        <MaterialCommunityIcons name={icon} size={compact ? 16 : 20} color={fg} />
      ) : null}
      <Text style={{ color: fg, fontWeight: '900', letterSpacing: 0.5, fontSize: compact ? 12 : 14 }}>
        {title.toUpperCase()}
      </Text>
    </Pressable>
  );
}

export function Chip({
  label,
  active,
  onPress,
  locked = false,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
  locked?: boolean;
}) {
  return (
    <Pressable
      onPress={() => {
        selectionTick();
        onPress();
      }}
      style={{
        paddingVertical: 8,
        paddingHorizontal: 14,
        borderRadius: 999,
        borderWidth: 1,
        borderColor: active ? COLORS.green : COLORS.border,
        backgroundColor: active ? 'rgba(34,197,94,0.15)' : COLORS.elevated,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
      }}
    >
      {locked ? <MaterialCommunityIcons name="lock" size={12} color={COLORS.amber} /> : null}
      <Text style={{ color: active ? COLORS.greenLight : COLORS.text, fontWeight: '700', fontSize: 13 }}>
        {label}
      </Text>
    </Pressable>
  );
}

export function Field(props: TextInputProps) {
  return (
    <TextInput
      placeholderTextColor={COLORS.muted}
      autoCapitalize="none"
      {...props}
      style={[
        {
          backgroundColor: COLORS.elevated,
          borderWidth: 1,
          borderColor: COLORS.border,
          borderRadius: 12,
          paddingHorizontal: 14,
          paddingVertical: 12,
          color: COLORS.text,
          fontSize: 15,
        },
        props.style,
      ]}
    />
  );
}

export function TierBadge({ tier }: { tier: VipTier }) {
  const color = tier === 'elite' ? COLORS.amberLight : tier === 'pro' ? COLORS.greenLight : COLORS.muted;
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        borderWidth: 1,
        borderColor: color,
        borderRadius: 999,
        paddingHorizontal: 10,
        paddingVertical: 3,
      }}
    >
      <MaterialCommunityIcons name={tier === 'free' ? 'account' : 'crown'} size={12} color={color} />
      <Text style={{ color, fontSize: 11, fontWeight: '800' }}>{TIER_FEATURES[tier].label.toUpperCase()}</Text>
    </View>
  );
}

export function EstimateBadge() {
  return (
    <View
      style={{
        borderWidth: 1,
        borderColor: COLORS.amber,
        borderRadius: 6,
        paddingHorizontal: 6,
        paddingVertical: 1,
      }}
    >
      <Text style={{ color: COLORS.amber, fontSize: 10, fontWeight: '800' }}>ESTIMATE</Text>
    </View>
  );
}

export function LockBanner({ text, onUpgrade }: { text: string; onUpgrade: () => void }) {
  return (
    <Card tone="gold">
      <Row>
        <MaterialCommunityIcons name="lock" size={18} color={COLORS.amberLight} />
        <Text style={{ color: COLORS.amberLight, fontWeight: '800', flex: 1 }}>{text}</Text>
      </Row>
      <NeonButton title="See plans" variant="gold" onPress={onUpgrade} compact />
    </Card>
  );
}

export function StatTile({ label, value, accent = COLORS.greenLight }: { label: string; value: string; accent?: string }) {
  return (
    <View
      style={{
        flexBasis: '30%',
        flexGrow: 1,
        backgroundColor: COLORS.elevated,
        borderRadius: 12,
        padding: 10,
        borderWidth: 1,
        borderColor: COLORS.border,
      }}
    >
      <Text style={{ color: COLORS.muted, fontSize: 11, fontWeight: '700' }}>{label}</Text>
      <Text style={{ color: accent, fontSize: 22, fontWeight: '900' }}>{value}</Text>
    </View>
  );
}

/* ------------------------------ slider ------------------------------ */

function StepButton({ icon, onPress }: { icon: IconName; onPress: () => void }) {
  return (
    <Pressable
      onPress={() => {
        selectionTick();
        onPress();
      }}
      hitSlop={6}
      style={{
        width: 30,
        height: 30,
        borderRadius: 15,
        backgroundColor: COLORS.elevated,
        borderWidth: 1,
        borderColor: COLORS.border,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <MaterialCommunityIcons name={icon} size={16} color={COLORS.text} />
    </Pressable>
  );
}

export function SensiSlider({
  label,
  hint,
  value,
  max,
  onChange,
  color = COLORS.green,
}: {
  label: string;
  hint: string;
  value: number;
  max: number;
  onChange: (value: number) => void;
  color?: string;
}) {
  const widthRef = useRef(1);
  const startX = useRef(0);
  const live = useRef({ value, max, onChange });
  live.current = { value, max, onChange };

  const emit = (x: number): void => {
    const { value: current, max: top, onChange: cb } = live.current;
    const next = Math.round(clampNum(x / widthRef.current, 0, 1) * top);
    if (next !== current) {
      selectionTick();
      cb(next);
    }
  };

  const responder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (e) => {
        startX.current = e.nativeEvent.locationX;
        emit(startX.current);
      },
      onPanResponderMove: (_e, g) => emit(startX.current + g.dx),
    }),
  ).current;

  const bump = (delta: number): void => onChange(clampNum(value + delta, 0, max));
  const ratio = (clampNum(value, 0, max) / max) * 100;

  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          <Text style={{ color: COLORS.text, fontWeight: '800' }}>{label}</Text>
          <Text style={{ color: COLORS.muted, fontSize: 12 }}>{hint}</Text>
        </View>
        <Text style={{ color, fontSize: 26, fontWeight: '900' }}>{value}</Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <StepButton icon="minus" onPress={() => bump(-1)} />
        <View
          {...responder.panHandlers}
          onLayout={(e: LayoutChangeEvent) => {
            widthRef.current = Math.max(1, e.nativeEvent.layout.width);
          }}
          style={{ flex: 1, height: 36, justifyContent: 'center' }}
        >
          <View pointerEvents="none" style={{ height: 8, borderRadius: 4, backgroundColor: COLORS.track }}>
            <View style={{ width: pct(ratio), height: 8, borderRadius: 4, backgroundColor: color }} />
          </View>
          <View
            pointerEvents="none"
            style={{
              position: 'absolute',
              left: pct(ratio),
              marginLeft: -11,
              width: 22,
              height: 22,
              borderRadius: 11,
              backgroundColor: '#FFFFFF',
              borderWidth: 3,
              borderColor: color,
            }}
          />
        </View>
        <StepButton icon="plus" onPress={() => bump(1)} />
      </View>
    </View>
  );
}

/* ------------------------------ visuals ------------------------------ */

export function FireButtonPreview({ percent }: { percent: number }) {
  const size = 40 + (clampNum(percent, 0, 100) / 100) * 120;
  return (
    <View style={{ height: 170, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: 'rgba(239,68,68,0.22)',
          borderWidth: 3,
          borderColor: COLORS.red,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <MaterialCommunityIcons name="fire" size={size * 0.45} color={COLORS.red} />
      </View>
    </View>
  );
}

const HUD: Record<FingerLayout, { note: string; dots: { x: number; y: number; label: string }[] }> = {
  2: {
    note: 'Two thumbs: aim and fire on the right thumb.',
    dots: [
      { x: 0.12, y: 0.66, label: 'MOVE' },
      { x: 0.78, y: 0.4, label: 'AIM' },
      { x: 0.9, y: 0.74, label: 'FIRE' },
    ],
  },
  3: {
    note: 'Three fingers: left index adds a second fire button.',
    dots: [
      { x: 0.12, y: 0.66, label: 'MOVE' },
      { x: 0.78, y: 0.4, label: 'AIM' },
      { x: 0.9, y: 0.74, label: 'FIRE' },
      { x: 0.2, y: 0.22, label: 'FIRE L' },
    ],
  },
  4: {
    note: 'Four fingers: both index fingers shoot, thumbs move and aim.',
    dots: [
      { x: 0.12, y: 0.66, label: 'MOVE' },
      { x: 0.78, y: 0.4, label: 'AIM' },
      { x: 0.9, y: 0.74, label: 'FIRE' },
      { x: 0.2, y: 0.22, label: 'FIRE L' },
      { x: 0.8, y: 0.12, label: 'SCOPE' },
    ],
  },
};

export function HudDiagram({ layout, firePercent }: { layout: FingerLayout; firePercent: number }) {
  const cfg = HUD[layout];
  const dot = 14 + (clampNum(firePercent, 0, 100) / 100) * 22;
  return (
    <View style={{ gap: 8 }}>
      <View
        style={{
          height: 120,
          borderRadius: 14,
          borderWidth: 2,
          borderColor: COLORS.border,
          backgroundColor: COLORS.bg,
        }}
      >
        {cfg.dots.map((d) => (
          <View
            key={d.label}
            style={{
              position: 'absolute',
              left: pct(d.x * 100),
              top: pct(d.y * 100),
              marginLeft: -dot / 2,
              marginTop: -dot / 2,
              alignItems: 'center',
            }}
          >
            <View
              style={{
                width: dot,
                height: dot,
                borderRadius: dot / 2,
                backgroundColor: d.label.startsWith('FIRE') ? 'rgba(239,68,68,0.5)' : 'rgba(34,197,94,0.35)',
                borderWidth: 2,
                borderColor: d.label.startsWith('FIRE') ? COLORS.red : COLORS.green,
              }}
            />
            <Text style={{ color: COLORS.muted, fontSize: 8, fontWeight: '800', marginTop: 1 }}>{d.label}</Text>
          </View>
        ))}
      </View>
      <Text style={{ color: COLORS.muted, fontSize: 12 }}>{cfg.note}</Text>
    </View>
  );
}

const BASE_ANGLE: Record<WeaponCategory, number> = { shotgun: 10, smg: 5, rifle: 7, sniper: 3 };

export function dragAngle(weapon: WeaponCategory, meters: number): number {
  return Math.round(BASE_ANGLE[weapon] + meters * 0.3);
}

export function RecoilGuide({ weapon }: { weapon: WeaponCategory }) {
  const distances = [10, 25, 50];
  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
        {distances.map((m) => {
          const angle = dragAngle(weapon, m);
          return (
            <View key={m} style={{ alignItems: 'center', gap: 6 }}>
              <View
                style={{
                  width: 80,
                  height: 80,
                  borderRadius: 12,
                  backgroundColor: COLORS.bg,
                  borderWidth: 1,
                  borderColor: COLORS.border,
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  overflow: 'hidden',
                }}
              >
                <View
                  style={{
                    width: 4,
                    height: 66,
                    borderRadius: 2,
                    backgroundColor: COLORS.green,
                    marginBottom: 4,
                    transformOrigin: 'bottom',
                    transform: [{ rotate: `${angle}deg` }],
                  }}
                />
              </View>
              <Text style={{ color: COLORS.text, fontWeight: '800' }}>{m} m</Text>
              <Text style={{ color: COLORS.greenLight, fontWeight: '900' }}>{angle}°</Text>
            </View>
          );
        })}
      </View>
      <Text style={{ color: COLORS.muted, fontSize: 12 }}>
        Starting angles for the drag direction, measured from straight up. Confirm them on the training ground.
      </Text>
    </View>
  );
}
