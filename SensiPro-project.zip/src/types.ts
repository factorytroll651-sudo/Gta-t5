export type GameVersion = 'freefire_india' | 'freefire_max' | 'freefire_global';
export type VipTier = 'free' | 'pro' | 'elite';
export type PlayStyle = 'rusher' | 'support' | 'sniper' | 'igl';
export type GameMode = 'ranked_br' | 'contra_squad' | 'custom_1v1';
export type FingerLayout = 2 | 3 | 4;
export type WeaponCategory = 'shotgun' | 'smg' | 'rifle' | 'sniper';
export type AimProblem = 'over_head' | 'stuck_chest' | 'shaking';
export type DeviceTier = 'entry' | 'mid' | 'flagship' | 'gaming';
export type OptimizerId = 'miraPerfeita' | 'semRecuo' | 'fastClick' | 'fpsBooster';

export interface SensiValues {
  general: number;
  redDot: number;
  scope2x: number;
  scope4x: number;
  scopeAwm: number;
  freeLook: number;
}

export interface HardwareTuning {
  fireButtonSize: number; // percent
  recommendedDpi: number; // 0 = not applicable (iOS)
  pointerSpeed: number; // -3..3
  fingerLayout: FingerLayout;
}

export interface SensiProfile extends SensiValues, HardwareTuning {
  id: string;
  profileName: string;
  phoneModel: string;
  isFavorite: boolean;
  createdAt: string;
}

export interface DeviceSpec {
  id: string;
  brand: string;
  model: string;
  screenInches: number;
  refreshHz: number;
  tier: DeviceTier;
}

export const SENSI_KEYS: readonly (keyof SensiValues)[] = [
  'general',
  'redDot',
  'scope2x',
  'scope4x',
  'scopeAwm',
  'freeLook',
];
