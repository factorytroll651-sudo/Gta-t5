const { withAndroidManifest } = require('expo/config-plugins');

const PACKAGES = ['com.dts.freefireindia', 'com.dts.freefiremax', 'com.dts.freefireth'];

module.exports = function withGameQueries(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    const queries = manifest.queries ?? [];
    const existing = queries.flatMap((q) => (q.package ?? []).map((p) => p.$['android:name']));
    const missing = PACKAGES.filter((name) => !existing.includes(name));
    if (missing.length > 0) {
      queries.push({ package: missing.map((name) => ({ $: { 'android:name': name } })) });
    }
    manifest.queries = queries;
    return cfg;
  });
};
