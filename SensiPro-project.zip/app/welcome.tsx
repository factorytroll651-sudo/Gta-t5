import { useMemo, useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Card, Chip, Field, NeonButton, Row, Screen, SectionLabel, Title } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { searchDevices } from '@/constants/devices';
import { GAME_LABELS, GAME_LIST } from '@/constants/games';
import { detectDevice, getScreenMetrics } from '@/services/device';
import { selectionTick, successFeedback } from '@/services/feedback';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import type { DeviceSpec, GameVersion } from '@/types';

export default function WelcomeScreen() {
  const detected = useMemo(() => detectDevice(), []);
  const currentGame = useSettingsStore((s) => s.game);
  const scale = useSettingsStore((s) => s.scale);

  const [game, setGame] = useState<GameVersion>(currentGame);
  const [device, setDevice] = useState<DeviceSpec | null>(detected.match);
  const [query, setQuery] = useState('');

  const results = useMemo(() => (query.trim() ? searchDevices(query, 6) : []), [query]);
  const label = device ? device.model : detected.label;

  const onStart = (): void => {
    successFeedback();
    useSettingsStore.getState().completeOnboarding({
      game,
      deviceId: device?.id ?? null,
      deviceLabel: label,
    });
    useSensiStore.getState().generate(device, getScreenMetrics(), scale);
    router.replace('/(tabs)');
  };

  return (
    <Screen bottomInset>
      <View style={{ gap: 4, marginTop: 8 }}>
        <Text style={{ color: COLORS.greenLight, fontWeight: '800', letterSpacing: 2 }}>WELCOME TO</Text>
        <Title>SensiPro FF</Title>
        <Text className="text-muted">AI Coach & Sensi for Free Fire India, MAX and Global.</Text>
      </View>

      <Card tone="green">
        <SectionLabel>Your phone</SectionLabel>
        <Text style={{ color: COLORS.text, fontSize: 18, fontWeight: '900' }}>{label}</Text>
        {device ? (
          <Text className="text-muted">
            Matched: {device.screenInches}" · {device.refreshHz} Hz · {device.tier} tier
          </Text>
        ) : (
          <Text className="text-muted">
            No exact match for {detected.label}. Search your model below, or continue and the screen size will be used.
          </Text>
        )}
        <Field value={query} onChangeText={setQuery} placeholder="Search model, e.g. Redmi Note 13" />
        {results.map((d) => (
          <Pressable
            key={d.id}
            onPress={() => {
              selectionTick();
              setDevice(d);
              setQuery('');
            }}
            style={{ paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border }}
          >
            <Text style={{ color: COLORS.text, fontWeight: '700' }}>{d.model}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              {d.brand} · {d.refreshHz} Hz
            </Text>
          </Pressable>
        ))}
      </Card>

      <Card>
        <SectionLabel>Which Free Fire do you play?</SectionLabel>
        <Row>
          {GAME_LIST.map((g) => (
            <Chip key={g} label={GAME_LABELS[g]} active={g === game} onPress={() => setGame(g)} />
          ))}
        </Row>
      </Card>

      <NeonButton title="Start" icon="play" onPress={onStart} />
    </Screen>
  );
}
