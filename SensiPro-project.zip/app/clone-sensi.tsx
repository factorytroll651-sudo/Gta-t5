import { useState } from 'react';
import { Alert, Image, Text } from 'react-native';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { Card, Field, LockBanner, NeonButton, Row, Screen, ScreenHeader, SectionLabel, SensiSlider } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { TIER_FEATURES } from '@/constants/pricing';
import { successFeedback, warnFeedback } from '@/services/feedback';
import { extractSensiFromImage, type OcrExtraction } from '@/services/ocrExtractor';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';
import { SENSI_KEYS } from '@/types';
import type { SensiValues } from '@/types';

const LABELS: Record<keyof SensiValues, string> = {
  general: 'Geral',
  redDot: 'Ponto Vermelho',
  scope2x: 'Mira 2x',
  scope4x: 'Mira 4x',
  scopeAwm: 'Mira AWM',
  freeLook: 'Olhadinha',
};

export default function CloneSensiScreen() {
  const tier = useUserStore((s) => s.vipTier);
  const scale = useSettingsStore((s) => s.scale);
  const current = useSensiStore((s) => s.values);
  const currentTuning = useSensiStore((s) => s.tuning);

  const [uri, setUri] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [extraction, setExtraction] = useState<OcrExtraction | null>(null);
  const [values, setValues] = useState<SensiValues>(current);
  const [fireSize, setFireSize] = useState<number>(currentTuning.fireButtonSize);
  const [dpi, setDpi] = useState<number>(currentTuning.recommendedDpi);
  const [name, setName] = useState('');

  if (!TIER_FEATURES[tier].cloneSensi) {
    return (
      <Screen bottomInset>
        <ScreenHeader title="Clone Sensi" subtitle="Scan a settings screenshot and copy the numbers." />
        <LockBanner text="Clone Sensi is part of the Elite plan." onUpgrade={() => router.push('/plans')} />
      </Screen>
    );
  }

  const pick = async (): Promise<void> => {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 1 });
    if (res.canceled || res.assets.length === 0) return;
    const asset = res.assets[0];
    setUri(asset.uri);
    setExtraction(null);
    setBusy(true);
    try {
      const out = await extractSensiFromImage(asset.uri);
      setExtraction(out);
      setValues((prev) => {
        const next: SensiValues = { ...prev };
        for (const k of SENSI_KEYS) {
          const found = out.values[k];
          if (found !== undefined) next[k] = Math.min(found, scale);
        }
        return next;
      });
      if (out.fireButtonSize !== null) setFireSize(out.fireButtonSize);
      if (out.dpi !== null) setDpi(out.dpi);
      if (out.matchedLabels.length === 0) {
        warnFeedback();
        Alert.alert('No settings found', 'The text reader did not find any sensitivity labels. Try a clearer, full-screen screenshot.');
      } else {
        successFeedback();
      }
    } catch {
      warnFeedback();
      Alert.alert('Scan failed', 'The text reader could not process this image.');
    } finally {
      setBusy(false);
    }
  };

  const save = (): void => {
    const title = name.trim();
    if (!title) {
      Alert.alert('Name your profile', 'Enter a name for the cloned setup.');
      return;
    }
    const store = useSensiStore.getState();
    store.applyPreset(values, { fireButtonSize: fireSize, recommendedDpi: dpi });
    store.saveProfile(title, useSettingsStore.getState().deviceLabel);
    successFeedback();
    Alert.alert('Saved', 'The cloned setup is now active and saved in your profiles.', [
      { text: 'OK', onPress: () => router.back() },
    ]);
  };

  return (
    <Screen bottomInset>
      <ScreenHeader title="Clone Sensi" subtitle="Pick a settings screenshot. Numbers next to the labels are read on your phone." />

      <NeonButton title={uri ? 'Pick another screenshot' : 'Pick screenshot'} icon="image-search" onPress={() => void pick()} loading={busy} />
      {uri ? <Image source={{ uri }} style={{ width: '100%', height: 180, borderRadius: 12 }} resizeMode="contain" /> : null}

      {extraction ? (
        <Card>
          <SectionLabel>Detected</SectionLabel>
          <Text style={{ color: COLORS.greenLight }}>{extraction.matchedLabels.join(' · ') || 'Nothing'}</Text>
          {extraction.missingLabels.length > 0 ? (
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              Not found (kept at your current value): {extraction.missingLabels.join(', ')}
            </Text>
          ) : null}
        </Card>
      ) : null}

      <Card>
        <SectionLabel>Review and edit</SectionLabel>
        {SENSI_KEYS.map((k) => (
          <SensiSlider
            key={k}
            label={LABELS[k]}
            hint=""
            value={values[k]}
            max={scale}
            onChange={(v) => setValues((prev) => ({ ...prev, [k]: v }))}
          />
        ))}
        <SensiSlider label="Fire button size" hint="Percent" value={fireSize} max={100} color={COLORS.red} onChange={setFireSize} />
        <Row>
          <Text style={{ color: COLORS.muted }}>DPI: {dpi > 0 ? dpi : 'not detected'}</Text>
        </Row>
      </Card>

      <Card>
        <Field value={name} onChangeText={setName} placeholder="Profile name" autoCapitalize="sentences" />
        <NeonButton title="Salvar como meu perfil" icon="check" onPress={save} />
      </Card>
    </Screen>
  );
}
