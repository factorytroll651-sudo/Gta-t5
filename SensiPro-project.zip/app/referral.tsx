import { useEffect, useState } from 'react';
import { Alert, Share, Text } from 'react-native';
import { router } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import { Card, Field, NeonButton, Screen, ScreenHeader, SectionLabel } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { BackendError, fetchMyReferralCode, redeemCode } from '@/services/backend';
import { successFeedback, warnFeedback } from '@/services/feedback';
import { isBackendConfigured } from '@/services/supabase';
import { useUserStore } from '@/stores/useUserStore';

export default function ReferralScreen() {
  const userId = useUserStore((s) => s.userId);
  const code = useUserStore((s) => s.referralCode);
  const redeemed = useUserStore((s) => s.redeemedCodes);

  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);

  const online = isBackendConfigured && userId !== null;

  useEffect(() => {
    if (!online || !userId) return;
    let cancelled = false;
    fetchMyReferralCode(userId)
      .then((serverCode) => {
        if (!cancelled && serverCode) useUserStore.getState().setReferralCode(serverCode);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [online, userId]);

  const share = async (): Promise<void> => {
    await Share.share({
      message: `Join me on SensiPro FF, the sensitivity and aim coach for Free Fire. Use my code ${code} when you sign up and we both get +2 Coach tokens.`,
    });
  };

  const redeem = async (): Promise<void> => {
    const clean = input.trim().toUpperCase();
    if (clean.length < 4) {
      Alert.alert('Check the code', 'Enter the full code.');
      return;
    }
    if (clean === code) {
      Alert.alert('That is your own code', 'Share it with a friend instead.');
      return;
    }
    if (redeemed.includes(clean)) {
      Alert.alert('Already redeemed', 'You already used this code.');
      return;
    }
    setBusy(true);
    try {
      const tokens = await redeemCode(clean);
      useUserStore.getState().addTokens(tokens);
      useUserStore.getState().markRedeemed(clean);
      setInput('');
      successFeedback();
      Alert.alert('Code redeemed', `+${tokens} Coach tokens added.`);
    } catch (e) {
      warnFeedback();
      Alert.alert('Could not redeem', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen bottomInset>
      <ScreenHeader title="Referral" subtitle="Friend joins with your code: you both get +2 Coach tokens." />

      <Card tone="green">
        <SectionLabel>Your code</SectionLabel>
        <Text style={{ color: COLORS.greenLight, fontSize: 32, fontWeight: '900', letterSpacing: 4 }}>{code}</Text>
        <NeonButton title="Share code" icon="share-variant" onPress={() => void share()} />
        <NeonButton
          title="Copy code"
          icon="content-copy"
          variant="dark"
          onPress={async () => {
            await Clipboard.setStringAsync(code);
            successFeedback();
          }}
        />
      </Card>

      <Card>
        <SectionLabel>Have a code?</SectionLabel>
        <Text style={{ color: COLORS.muted, fontSize: 13 }}>Friend referral codes and creator coupon codes both go here.</Text>
        {online ? (
          <>
            <Field value={input} onChangeText={(t) => setInput(t.toUpperCase())} placeholder="CODE" autoCapitalize="characters" />
            <NeonButton title="Redeem" onPress={() => void redeem()} loading={busy} />
          </>
        ) : (
          <>
            <Text style={{ color: COLORS.amberLight, fontSize: 13 }}>
              {isBackendConfigured
                ? 'Sign in to redeem codes. Rewards are checked on the server so a code can only be used once.'
                : 'Redeeming needs the online account service, which is not part of this build.'}
            </Text>
            {isBackendConfigured ? <NeonButton title="Sign in" variant="dark" onPress={() => router.push('/login')} /> : null}
          </>
        )}
      </Card>
    </Screen>
  );
}
