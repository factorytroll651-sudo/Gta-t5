import { Alert, Text, View } from 'react-native';
import { router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, Chip, NeonButton, Row, Screen, ScreenHeader, SectionLabel, TierBadge } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import {
  CURRENCIES,
  PRICES,
  TIER_FEATURES,
  TIER_ORDER,
  type Currency,
  type ProductId,
} from '@/constants/pricing';
import { successFeedback } from '@/services/feedback';
import { purchaseProduct, restorePurchases } from '@/services/purchases';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';
import type { VipTier } from '@/types';

const TIER_PRODUCTS: Record<Exclude<VipTier, 'free'>, ProductId[]> = {
  pro: ['pro_monthly'],
  elite: ['elite_annual', 'elite_lifetime'],
};

const PRODUCT_LABEL: Record<ProductId, string> = {
  tokens_3: '3 tokens',
  tokens_10: '10 tokens',
  pro_monthly: 'Monthly',
  elite_annual: 'Annual',
  elite_lifetime: 'Lifetime',
};

export default function PlansScreen() {
  const tier = useUserStore((s) => s.vipTier);
  const currency = useSettingsStore((s) => s.currency);

  const buy = async (id: ProductId): Promise<void> => {
    const outcome = await purchaseProduct(id);
    if (outcome.status === 'success') {
      if (outcome.tier) useUserStore.getState().setVipTier(outcome.tier, 'store');
      successFeedback();
      Alert.alert('Thank you', 'Your plan is active.');
    } else if (outcome.status === 'unavailable') {
      Alert.alert('Store unavailable', outcome.reason);
    } else if (outcome.status === 'error') {
      Alert.alert('Purchase failed', outcome.message);
    }
  };

  const restore = async (): Promise<void> => {
    const outcome = await restorePurchases();
    if (outcome.status === 'success') {
      const user = useUserStore.getState();
      if (outcome.tier) {
        user.setVipTier(outcome.tier, 'store');
        Alert.alert('Restored', `Your ${TIER_FEATURES[outcome.tier].label} plan is active again.`);
      } else {
        Alert.alert('Nothing to restore', 'No active purchases were found for this store account.');
      }
    } else if (outcome.status === 'unavailable') {
      Alert.alert('Store unavailable', outcome.reason);
    } else if (outcome.status === 'error') {
      Alert.alert('Restore failed', outcome.message);
    }
  };

  const priceOf = (id: ProductId, c: Currency): string | null => PRICES[c][id] ?? null;

  return (
    <Screen bottomInset>
      <ScreenHeader title="Plans" subtitle="Pick what fits your play." />

      <Row>
        {CURRENCIES.map((c) => (
          <Chip
            key={c}
            label={c}
            active={c === currency}
            onPress={() => useSettingsStore.getState().setCurrency(c)}
          />
        ))}
      </Row>
      <Text style={{ color: COLORS.muted, fontSize: 12 }}>
        Prices are list prices. Your store checkout shows the final amount and the payment methods it supports
        (on Google Play in India that includes UPI and cards).
      </Text>

      {TIER_ORDER.map((t) => {
        const f = TIER_FEATURES[t];
        const current = t === tier;
        return (
          <Card key={t} tone={t === 'elite' ? 'gold' : t === 'pro' ? 'green' : 'default'}>
            <Row>
              <TierBadge tier={t} />
              {current ? <Text style={{ color: COLORS.greenLight, fontWeight: '800' }}>Current plan</Text> : null}
            </Row>
            {f.perks.map((perk) => (
              <View key={perk} style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                <MaterialCommunityIcons name="check" size={16} color={COLORS.green} />
                <Text style={{ color: COLORS.text, flex: 1 }}>{perk}</Text>
              </View>
            ))}
            {t !== 'free'
              ? TIER_PRODUCTS[t].map((id) => {
                  const price = priceOf(id, currency);
                  if (!price) {
                    return (
                      <Text key={id} style={{ color: COLORS.muted, fontSize: 12 }}>
                        {PRODUCT_LABEL[id]} is not offered in {currency}. Switch currency to see it.
                      </Text>
                    );
                  }
                  return (
                    <NeonButton
                      key={id}
                      title={`${PRODUCT_LABEL[id]} · ${price}`}
                      variant={t === 'elite' ? 'gold' : 'green'}
                      disabled={current}
                      onPress={() => void buy(id)}
                    />
                  );
                })
              : null}
          </Card>
        );
      })}

      <SectionLabel>Already paid?</SectionLabel>
      <NeonButton title="Restore purchases" variant="dark" icon="download" onPress={() => void restore()} />
      <NeonButton title="Close" variant="dark" onPress={() => router.back()} />
    </Screen>
  );
}
