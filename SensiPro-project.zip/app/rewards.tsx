import { Alert, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, NeonButton, Screen, ScreenHeader } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { successFeedback, warnFeedback } from '@/services/feedback';
import { STREAK_LENGTH, computeClaimState } from '@/services/streak';
import { useUserStore } from '@/stores/useUserStore';

export default function RewardsScreen() {
  const streak = useUserStore((s) => s.streakCount);
  const lastClaim = useUserStore((s) => s.lastClaimDate);
  const tokens = useUserStore((s) => s.coachTokens);

  const state = computeClaimState(lastClaim, streak);
  // Day that is already collected in the current cycle.
  const collected = state.nextDay === 1 && !state.blocked ? 0 : state.blocked ? streak : state.nextDay - 1;

  const claim = (): void => {
    const result = useUserStore.getState().claimDaily();
    if (!result.ok) {
      warnFeedback();
      Alert.alert('Already claimed', 'Come back tomorrow for the next reward.');
      return;
    }
    successFeedback();
    Alert.alert(
      `Day ${result.day} claimed`,
      result.presetUnlocked
        ? '+1 Coach token, and the One-Tap Shotgun preset is unlocked in the Store tab.'
        : '+1 Coach token added.',
    );
  };

  return (
    <Screen bottomInset>
      <ScreenHeader title="Daily rewards" subtitle="Log in every day: +1 Coach token. Day 7 unlocks One-Tap Shotgun." />

      <Card tone="gold">
        <Text style={{ color: COLORS.amberLight, fontSize: 30, fontWeight: '900' }}>{tokens}</Text>
        <Text style={{ color: COLORS.muted }}>Coach tokens in your balance</Text>
      </Card>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {Array.from({ length: STREAK_LENGTH }, (_, i) => i + 1).map((day) => {
          const done = day <= collected;
          const next = !state.blocked && day === state.nextDay;
          return (
            <View
              key={day}
              style={{
                flexBasis: '22%',
                flexGrow: 1,
                aspectRatio: 1,
                borderRadius: 14,
                borderWidth: 1,
                borderColor: next ? COLORS.amber : done ? COLORS.green : COLORS.border,
                backgroundColor: done ? 'rgba(34,197,94,0.12)' : COLORS.card,
                alignItems: 'center',
                justifyContent: 'center',
                gap: 4,
              }}
            >
              <Text style={{ color: COLORS.muted, fontSize: 11, fontWeight: '800' }}>DAY {day}</Text>
              <MaterialCommunityIcons
                name={done ? 'check-circle' : day === STREAK_LENGTH ? 'star' : 'coin'}
                size={26}
                color={done ? COLORS.green : COLORS.amberLight}
              />
              <Text style={{ color: COLORS.text, fontSize: 11, fontWeight: '700' }}>
                {day === STREAK_LENGTH ? '+1 & preset' : '+1 token'}
              </Text>
            </View>
          );
        })}
      </View>

      <NeonButton
        title={state.blocked ? 'Claimed today' : `Claim day ${state.nextDay}`}
        variant="gold"
        icon="gift"
        disabled={state.blocked}
        onPress={claim}
      />
      {state.blocked ? (
        <Text style={{ color: COLORS.muted, fontSize: 12 }}>
          Next reward unlocks tomorrow. Missing a day restarts the streak at day 1.
        </Text>
      ) : null}
    </Screen>
  );
}
