import { useState, type ReactElement } from 'react';
import { Alert, Pressable, Switch, Text, View } from 'react-native';
import { router } from 'expo-router';
import * as Application from 'expo-application';
import { Card, Chip, NeonButton, Row, Screen, SectionLabel, TierBadge, Title } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { ENABLE_DEV_UNLOCK } from '@/constants/flags';
import { GAME_LABELS, GAME_LIST } from '@/constants/games';
import { BackendError, backupProfiles, restoreProfiles, signOut } from '@/services/backend';
import { successFeedback } from '@/services/feedback';
import { isBackendConfigured } from '@/services/supabase';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';

export default function SettingsScreen() {
  const game = useSettingsStore((s) => s.game);
  const haptics = useSettingsStore((s) => s.hapticsEnabled);
  const deviceLabel = useSettingsStore((s) => s.deviceLabel);
  const email = useUserStore((s) => s.email);
  const userId = useUserStore((s) => s.userId);
  const tier = useUserStore((s) => s.vipTier);
  const profileCount = useSensiStore((s) => s.profiles.length);

  const [tapCount, setTapCount] = useState(0);
  const [busy, setBusy] = useState(false);

  const handleSecretDevTap = (): void => {
    if (!ENABLE_DEV_UNLOCK) return;
    const next = tapCount + 1;
    setTapCount(next);
    if (next === 7) {
      const user = useUserStore.getState();
      user.setVipTier('elite', 'dev');
      user.addTokens(500);
      Alert.alert('🛠️ Dev Mode Activated', 'Sare VIP Features aur 500 Coach Tokens unlock ho gaye!');
      setTapCount(0);
    }
  };

  const backup = async (): Promise<void> => {
    if (!userId) return;
    setBusy(true);
    try {
      const n = await backupProfiles(userId, useSensiStore.getState().profiles);
      successFeedback();
      Alert.alert('Backup done', `${n} profile(s) saved to your account.`);
    } catch (e) {
      Alert.alert('Backup failed', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  const restore = async (): Promise<void> => {
    if (!userId) return;
    setBusy(true);
    try {
      const incoming = await restoreProfiles(userId);
      const added = useSensiStore.getState().mergeProfiles(incoming);
      successFeedback();
      Alert.alert('Restore done', `${added} new profile(s) added.`);
    } catch (e) {
      Alert.alert('Restore failed', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await signOut();
    } catch {
      // Clear locally even if the server call fails.
    }
    useUserStore.getState().clearAuth();
  };

  const link = (label: string, path: Parameters<typeof router.push>[0]): ReactElement => (
    <Pressable
      key={label}
      onPress={() => router.push(path)}
      style={{ paddingVertical: 12, borderTopWidth: 1, borderTopColor: COLORS.border }}
    >
      <Text style={{ color: COLORS.text, fontWeight: '700' }}>{label}</Text>
    </Pressable>
  );

  return (
    <Screen>
      <Title>Settings</Title>

      <Card>
        <SectionLabel>Game</SectionLabel>
        <Row>
          {GAME_LIST.map((g) => (
            <Chip key={g} label={GAME_LABELS[g]} active={g === game} onPress={() => useSettingsStore.getState().setGame(g)} />
          ))}
        </Row>
        <SectionLabel>Phone</SectionLabel>
        <Text style={{ color: COLORS.text, fontWeight: '800' }}>{deviceLabel}</Text>
        <NeonButton title="Change phone model" variant="dark" onPress={() => router.push('/welcome')} />
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text style={{ color: COLORS.text, fontWeight: '700' }}>Haptic feedback</Text>
          <Switch
            value={haptics}
            onValueChange={(v) => useSettingsStore.getState().setHaptics(v)}
            trackColor={{ true: COLORS.green, false: COLORS.track }}
          />
        </View>
      </Card>

      <Card>
        <Row>
          <SectionLabel>Account</SectionLabel>
          <View style={{ marginLeft: 'auto' }}>
            <TierBadge tier={tier} />
          </View>
        </Row>
        {isBackendConfigured ? (
          email ? (
            <>
              <Text style={{ color: COLORS.text }}>{email}</Text>
              <NeonButton title="Back up profiles" icon="cloud-upload" variant="dark" onPress={() => void backup()} loading={busy} />
              <NeonButton title="Restore profiles" icon="cloud-download" variant="dark" onPress={() => void restore()} loading={busy} />
              <NeonButton title="Sign out" icon="logout" variant="dark" onPress={() => void logout()} />
            </>
          ) : (
            <NeonButton title="Sign in" icon="email-outline" onPress={() => router.push('/login')} />
          )
        ) : (
          <Text style={{ color: COLORS.muted, fontSize: 13 }}>
            Offline mode: {profileCount} profile(s) saved on this phone. Cloud backup is not part of this build.
          </Text>
        )}
        {link('Plans and VIP', '/plans')}
        {link('Daily rewards', '/rewards')}
        {link('Clone Sensi (Elite)', '/clone-sensi')}
        {link('Referral and coupon codes', '/referral')}
        {link('Support', '/support')}
      </Card>

      <Pressable onPress={handleSecretDevTap} style={{ paddingVertical: 16, alignItems: 'center' }}>
        <Text style={{ color: COLORS.muted, fontSize: 11, fontFamily: 'monospace' }}>
          Versão {Application.nativeApplicationVersion ?? '1.0.0'} (Build {Application.nativeBuildVersion ?? '1'}) -{' '}
          {GAME_LABELS[game]}
        </Text>
      </Pressable>
    </Screen>
  );
}
