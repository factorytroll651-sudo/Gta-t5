import { Alert, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Card, EstimateBadge, NeonButton, Row, Screen, SectionLabel, Title } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { INFLUENCER_PRESETS, ONE_TAP_SHOTGUN, type InfluencerPreset } from '@/constants/influencers';
import { PRICES, TIER_FEATURES, type ProductId } from '@/constants/pricing';
import { successFeedback, warnFeedback } from '@/services/feedback';
import { purchaseProduct } from '@/services/purchases';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';
import { SENSI_KEYS } from '@/types';
import type { SensiValues } from '@/types';

const REGION_LABEL: Record<InfluencerPreset['region'], string> = { IN: 'India', BR: 'Brazil', GLOBAL: 'Global' };

const TOKEN_PRODUCTS: ProductId[] = ['tokens_3', 'tokens_10'];

export default function StoreScreen() {
  const tier = useUserStore((s) => s.vipTier);
  const unlocked = useUserStore((s) => s.unlockedPresetIds);
  const currency = useSettingsStore((s) => s.currency);
  const scale = useSettingsStore((s) => s.scale);
  const features = TIER_FEATURES[tier];

  const buyTokens = async (id: ProductId): Promise<void> => {
    const outcome = await purchaseProduct(id);
    if (outcome.status === 'success') {
      useUserStore.getState().addTokens(outcome.tokens);
      successFeedback();
      Alert.alert('Tokens added', `${outcome.tokens} Coach tokens added.`);
    } else if (outcome.status === 'unavailable') {
      Alert.alert('Store unavailable', outcome.reason);
    } else if (outcome.status === 'error') {
      Alert.alert('Purchase failed', outcome.message);
    }
  };

  const canUse = (p: InfluencerPreset): boolean =>
    !p.isVipOnly || features.allCreators || unlocked.includes(p.id);

  const apply = (p: InfluencerPreset): void => {
    if (!canUse(p)) {
      warnFeedback();
      Alert.alert('Elite preset', `${p.name} is part of the Elite plan.`, [
        { text: 'Not now', style: 'cancel' },
        { text: 'See plans', onPress: () => router.push('/plans') },
      ]);
      return;
    }
    const values: SensiValues = {
      general: p.general,
      redDot: p.redDot,
      scope2x: p.scope2x,
      scope4x: p.scope4x,
      scopeAwm: p.scopeAwm,
      freeLook: p.freeLook,
    };
    const clamped: SensiValues = { ...values };
    for (const k of SENSI_KEYS) clamped[k] = Math.min(values[k], scale);
    useSensiStore.getState().applyPreset(clamped, {
      fireButtonSize: p.fireButtonSize,
      recommendedDpi: p.recommendedDpi,
    });
    successFeedback();
    Alert.alert('Applied', `${p.name} preset is now your active setup.`);
  };

  const catalog: InfluencerPreset[] = unlocked.includes(ONE_TAP_SHOTGUN.id)
    ? [ONE_TAP_SHOTGUN, ...INFLUENCER_PRESETS]
    : [...INFLUENCER_PRESETS];

  return (
    <Screen>
      <Title>Store</Title>

      <Card tone="gold">
        <SectionLabel>Membership</SectionLabel>
        <Text style={{ color: COLORS.text }}>
          You are on <Text style={{ fontWeight: '900', color: COLORS.amberLight }}>{features.label}</Text>.
        </Text>
        <NeonButton title="Compare plans" variant="gold" icon="crown" onPress={() => router.push('/plans')} />
      </Card>

      <Card>
        <SectionLabel>Coach token bundles</SectionLabel>
        <Row>
          {TOKEN_PRODUCTS.map((id) => (
            <View key={id} style={{ flex: 1, minWidth: 130 }}>
              <NeonButton
                title={`${id === 'tokens_3' ? '3' : '10'} tokens · ${PRICES[currency][id] ?? PRICES.INR[id] ?? ''}`}
                variant="dark"
                icon="coin"
                onPress={() => void buyTokens(id)}
              />
            </View>
          ))}
        </Row>
      </Card>

      <SectionLabel>Creator presets</SectionLabel>
      <Text style={{ color: COLORS.muted, fontSize: 12 }}>
        These are approximate setups made by SensiPro, not values published by the creators, and the creators are
        not affiliated with this app.
      </Text>
      {catalog.map((p) => {
        const open = canUse(p);
        return (
          <Card key={p.id} tone={open ? 'default' : 'elevated'}>
            <Row>
              <Text style={{ color: COLORS.text, fontSize: 16, fontWeight: '900', flexShrink: 1 }}>{p.name}</Text>
              {!p.confirmed ? <EstimateBadge /> : null}
            </Row>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              {REGION_LABEL[p.region]} · {p.weaponFocus}
            </Text>
            <Text style={{ color: COLORS.greenLight, fontWeight: '800' }}>
              {p.general} / {p.redDot} / {p.scope2x} / {p.scope4x} / {p.scopeAwm} / {p.freeLook}
            </Text>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              Fire button {p.fireButtonSize}% · DPI {p.recommendedDpi}
            </Text>
            <NeonButton
              title={open ? 'Apply to my setup' : 'Unlock with Elite'}
              variant={open ? 'green' : 'gold'}
              icon={open ? 'check' : 'lock'}
              compact
              onPress={() => apply(p)}
            />
          </Card>
        );
      })}
    </Screen>
  );
}
