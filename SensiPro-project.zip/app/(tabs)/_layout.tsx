import { View } from 'react-native';
import { Redirect, Tabs } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '@/constants/theme';
import { useSettingsStore } from '@/stores/useSettingsStore';
import type { IconName } from '@/components/ui';

const ICONS: Record<string, IconName> = {
  index: 'home',
  sensi: 'tune-variant',
  loja: 'store',
  settings: 'cog',
};

export default function TabsLayout() {
  const hasOnboarded = useSettingsStore((s) => s.hasOnboarded);
  if (!hasOnboarded) return <Redirect href="/welcome" />;

  return (
    <Tabs
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: COLORS.greenLight,
        tabBarInactiveTintColor: COLORS.muted,
        tabBarStyle: { backgroundColor: COLORS.card, borderTopColor: COLORS.border },
        tabBarLabelStyle: { fontWeight: '800', fontSize: 11 },
        tabBarIcon: ({ focused, color }) => (
          <View style={{ alignItems: 'center' }}>
            <View
              style={{
                height: 3,
                width: 24,
                borderRadius: 2,
                marginBottom: 4,
                backgroundColor: focused ? COLORS.green : 'transparent',
              }}
            />
            <MaterialCommunityIcons name={ICONS[route.name] ?? 'circle'} size={24} color={color} />
          </View>
        ),
      })}
    >
      <Tabs.Screen name="index" options={{ title: 'Home' }} />
      <Tabs.Screen name="sensi" options={{ title: 'Sensi' }} />
      <Tabs.Screen name="loja" options={{ title: 'Store' }} />
      <Tabs.Screen name="settings" options={{ title: 'Settings' }} />
    </Tabs>
  );
}
