import { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import * as ImagePicker from 'expo-image-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  Card,
  Chip,
  NeonButton,
  Row,
  Screen,
  SectionLabel,
  StatTile,
  TierBadge,
  Title,
} from '@/components/ui';
import { LaunchBar } from '@/components/LaunchBar';
import { COLORS } from '@/constants/theme';
import { TIER_FEATURES } from '@/constants/pricing';
import { getAccessToken } from '@/services/backend';
import {
  CoachApiError,
  analyzeClip,
  buildCoachReport,
  formatSensiText,
  type ClipAnalysis,
  type CoachReport,
} from '@/services/coachEngine';
import { todayKey } from '@/services/dates';
import { successFeedback, warnFeedback } from '@/services/feedback';
import { computeClaimState, dailyRemaining } from '@/services/streak';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';
import type { AimProblem, GameMode, PlayStyle } from '@/types';

type CoachTab = 'quick' | 'clip';

const ROLES: { id: PlayStyle; label: string }[] = [
  { id: 'rusher', label: 'Rusher' },
  { id: 'support', label: 'Support' },
  { id: 'sniper', label: 'Sniper' },
  { id: 'igl', label: 'IGL' },
];

const MODES: { id: GameMode; label: string }[] = [
  { id: 'ranked_br', label: 'Ranked Battle Royale' },
  { id: 'contra_squad', label: 'Contra Squad (CS)' },
  { id: 'custom_1v1', label: '1v1 Custom Room' },
];

const PROBLEMS: { id: AimProblem; label: string }[] = [
  { id: 'over_head', label: 'Bullets fly over the enemy head' },
  { id: 'stuck_chest', label: 'Bullets stick to the chest / not rising' },
  { id: 'shaking', label: 'Aim shakes horizontally' },
];

const DRAG_LABEL: Record<ClipAnalysis['dragSpeed'], string> = {
  too_slow: 'Too slow',
  ideal: 'Ideal',
  too_aggressive: 'Too aggressive',
};

export default function HomeScreen() {
  const tier = useUserStore((s) => s.vipTier);
  const tokens = useUserStore((s) => s.coachTokens);
  const usedDate = useUserStore((s) => s.dailyCoachDate);
  const used = useUserStore((s) => s.dailyCoachUsed);
  const lastClaim = useUserStore((s) => s.lastClaimDate);
  const streak = useUserStore((s) => s.streakCount);
  const scale = useSettingsStore((s) => s.scale);
  const deviceLabel = useSettingsStore((s) => s.deviceLabel);
  const values = useSensiStore((s) => s.values);
  const tuning = useSensiStore((s) => s.tuning);

  const [tab, setTab] = useState<CoachTab>('quick');
  const [role, setRole] = useState<PlayStyle | null>(null);
  const [mode, setMode] = useState<GameMode | null>(null);
  const [report, setReport] = useState<CoachReport | null>(null);

  const [clip, setClip] = useState<{ uri: string; mimeType: string; name: string } | null>(null);
  const [analysis, setAnalysis] = useState<ClipAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const remaining = dailyRemaining(TIER_FEATURES[tier].coachPerDay, usedDate, used, todayKey());
  const claimable = !computeClaimState(lastClaim, streak).blocked;

  const goPlans = (): void => router.push('/plans');

  const runDiagnosis = (problem: AimProblem): void => {
    if (!role || !mode) return;
    if (!useUserStore.getState().consumeDailyCoach()) {
      warnFeedback();
      Alert.alert(
        'Daily Coach IA limit reached',
        'You used all of today\'s guided diagnoses. Come back tomorrow or upgrade for more.',
        [
          { text: 'Not now', style: 'cancel' },
          { text: 'See plans', onPress: goPlans },
        ],
      );
      return;
    }
    successFeedback();
    setReport(buildCoachReport({ role, mode, problem, values, tuning, maxScale: scale }));
  };

  const resetDiagnosis = (): void => {
    setRole(null);
    setMode(null);
    setReport(null);
  };

  const copyReport = async (r: CoachReport): Promise<void> => {
    await Clipboard.setStringAsync(r.clipboardText);
    successFeedback();
    Alert.alert('Copied', 'Open the game settings and enter these numbers.');
  };

  const pickClip = async (): Promise<void> => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['videos', 'images'],
      quality: 1,
    });
    if (res.canceled || res.assets.length === 0) return;
    const asset = res.assets[0];
    if (asset.type === 'video' && asset.duration !== null && asset.duration !== undefined && asset.duration > 20000) {
      Alert.alert('Clip too long', 'Pick a clip of 5 to 15 seconds.');
      return;
    }
    setAnalysis(null);
    setClip({
      uri: asset.uri,
      mimeType: asset.mimeType ?? (asset.type === 'video' ? 'video/mp4' : 'image/jpeg'),
      name: asset.fileName ?? 'clip',
    });
  };

  const runAnalysis = async (): Promise<void> => {
    if (!clip) return;
    const user = useUserStore.getState();
    if (user.vipTier !== 'elite' && user.coachTokens <= 0) {
      warnFeedback();
      Alert.alert('No Coach tokens', 'Claim a daily reward or buy tokens in the store.', [
        { text: 'Rewards', onPress: () => router.push('/rewards') },
        { text: 'Store', onPress: () => router.push('/(tabs)/loja') },
      ]);
      return;
    }
    setAnalyzing(true);
    try {
      const result = await analyzeClip(clip, await getAccessToken());
      // Spend the token only after the server returned a result.
      useUserStore.getState().spendToken();
      successFeedback();
      setAnalysis(result);
    } catch (e) {
      warnFeedback();
      const message =
        e instanceof CoachApiError && e.code === 'not_configured'
          ? 'Clip analysis needs the Coach server, which is not connected in this build. No token was used.'
          : e instanceof CoachApiError
            ? `${e.message} No token was used.`
            : 'Something went wrong. No token was used.';
      Alert.alert('Analysis unavailable', message);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <Screen>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Title>SensiPro FF</Title>
          <Text style={{ color: COLORS.muted, fontSize: 12 }}>{deviceLabel}</Text>
        </View>
        <Pressable onPress={goPlans}>
          <TierBadge tier={tier} />
        </Pressable>
      </View>

      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Pressable
          onPress={() => router.push('/rewards')}
          style={{
            flex: 1,
            backgroundColor: COLORS.card,
            borderWidth: 1,
            borderColor: claimable ? COLORS.amber : COLORS.border,
            borderRadius: 14,
            padding: 12,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <MaterialCommunityIcons name="coin" size={26} color={COLORS.amberLight} />
          <View>
            <Text style={{ color: COLORS.amberLight, fontSize: 22, fontWeight: '900' }}>
              {tier === 'elite' ? '∞' : tokens}
            </Text>
            <Text style={{ color: COLORS.muted, fontSize: 11 }}>Coach tokens</Text>
          </View>
        </Pressable>
        <Pressable
          onPress={() => router.push('/rewards')}
          style={{
            flex: 1,
            backgroundColor: COLORS.card,
            borderWidth: 1,
            borderColor: claimable ? COLORS.amber : COLORS.border,
            borderRadius: 14,
            padding: 12,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <MaterialCommunityIcons name="gift" size={26} color={claimable ? COLORS.amberLight : COLORS.muted} />
          <View style={{ flex: 1 }}>
            <Text style={{ color: COLORS.text, fontWeight: '800' }}>{claimable ? 'Reward ready' : 'Claimed today'}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 11 }}>7-day streak</Text>
          </View>
        </Pressable>
      </View>

      <Card tone="elevated">
        <Row>
          <MaterialCommunityIcons name="brain" size={20} color={COLORS.greenLight} />
          <Text style={{ color: COLORS.text, fontSize: 18, fontWeight: '900' }}>Coach IA</Text>
          <Text style={{ color: COLORS.muted, fontSize: 12, marginLeft: 'auto' }}>
            {Number.isFinite(remaining) ? `${remaining} diagnosis left today` : 'Unlimited'}
          </Text>
        </Row>
        <Row>
          <Chip label="Instant fix" active={tab === 'quick'} onPress={() => setTab('quick')} />
          <Chip label="Clip analysis" active={tab === 'clip'} onPress={() => setTab('clip')} />
        </Row>

        {tab === 'quick' ? (
          report ? (
            <View style={{ gap: 10 }}>
              <Text style={{ color: COLORS.text, fontWeight: '800' }}>{report.headline}</Text>
              {report.changes.map((c) => (
                <View key={c.label} style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={{ color: COLORS.muted }}>{c.label}</Text>
                  <Text style={{ color: COLORS.greenLight, fontWeight: '900' }}>
                    {c.from} → {c.to}
                  </Text>
                </View>
              ))}
              {report.tips.map((t) => (
                <Text key={t} style={{ color: COLORS.muted, fontSize: 13 }}>
                  • {t}
                </Text>
              ))}
              <NeonButton title="Copiar para o jogo" icon="content-copy" onPress={() => void copyReport(report)} />
              <NeonButton
                title="Apply to my setup"
                variant="dark"
                onPress={() => {
                  useSensiStore.getState().applyCoachReport(report);
                  successFeedback();
                  Alert.alert('Applied', 'Your active sensitivity now uses the adjusted numbers.');
                }}
              />
              <NeonButton title="New diagnosis" variant="dark" onPress={resetDiagnosis} />
            </View>
          ) : !role ? (
            <View style={{ gap: 8 }}>
              <SectionLabel>Step 1 · Your role</SectionLabel>
              <Row>
                {ROLES.map((r) => (
                  <Chip key={r.id} label={r.label} active={false} onPress={() => setRole(r.id)} />
                ))}
              </Row>
            </View>
          ) : !mode ? (
            <View style={{ gap: 8 }}>
              <SectionLabel>Step 2 · Game mode</SectionLabel>
              <Row>
                {MODES.map((m) => (
                  <Chip key={m.id} label={m.label} active={false} onPress={() => setMode(m.id)} />
                ))}
              </Row>
            </View>
          ) : (
            <View style={{ gap: 8 }}>
              <SectionLabel>Step 3 · What is failing?</SectionLabel>
              {PROBLEMS.map((p) => (
                <NeonButton key={p.id} title={p.label} variant="dark" onPress={() => runDiagnosis(p.id)} />
              ))}
            </View>
          )
        ) : (
          <View style={{ gap: 10 }}>
            <Text style={{ color: COLORS.muted, fontSize: 13 }}>
              Upload a 5 to 15 second training-ground clip or a screenshot. Costs 1 Coach token (Elite is unlimited).
            </Text>
            <NeonButton
              title={clip ? 'Pick a different clip' : 'Pick clip or screenshot'}
              icon="video"
              variant="dark"
              onPress={() => void pickClip()}
            />
            {clip ? <Text style={{ color: COLORS.text, fontSize: 12 }}>Selected: {clip.name}</Text> : null}
            <NeonButton
              title="Analyze"
              icon="brain"
              disabled={!clip}
              loading={analyzing}
              onPress={() => void runAnalysis()}
            />
            {analysis ? (
              <View style={{ gap: 8 }}>
                <Row>
                  <StatTile label="Headshot accuracy" value={`${analysis.headshotAccuracy}%`} />
                  <StatTile label="Taxa de capa" value={`${analysis.headshotRatePrediction}%`} />
                  <StatTile
                    label="Drag speed"
                    value={DRAG_LABEL[analysis.dragSpeed]}
                    accent={analysis.dragSpeed === 'ideal' ? COLORS.greenLight : COLORS.amberLight}
                  />
                </Row>
                {analysis.checklist.map((c) => (
                  <Text key={c} style={{ color: COLORS.muted, fontSize: 13 }}>
                    ✓ {c}
                  </Text>
                ))}
              </View>
            ) : null}
          </View>
        )}
      </Card>

      <Card>
        <Row>
          <SectionLabel>Active sensitivity</SectionLabel>
          <Pressable onPress={() => router.push('/(tabs)/sensi')} style={{ marginLeft: 'auto' }}>
            <Text style={{ color: COLORS.greenLight, fontWeight: '800' }}>Edit</Text>
          </Pressable>
        </Row>
        <Row>
          <StatTile label="Geral" value={String(values.general)} />
          <StatTile label="Red Dot" value={String(values.redDot)} />
          <StatTile label="2x" value={String(values.scope2x)} />
          <StatTile label="4x" value={String(values.scope4x)} />
          <StatTile label="AWM" value={String(values.scopeAwm)} />
          <StatTile label="Look" value={String(values.freeLook)} />
        </Row>
        <Text style={{ color: COLORS.muted, fontSize: 12 }}>
          Fire button {tuning.fireButtonSize}%
          {tuning.recommendedDpi > 0 ? ` · DPI ${tuning.recommendedDpi}` : ''} · Pointer{' '}
          {tuning.pointerSpeed > 0 ? '+' : ''}
          {tuning.pointerSpeed}
        </Text>
        <NeonButton
          title="Copiar para o jogo"
          icon="content-copy"
          variant="dark"
          onPress={async () => {
            await Clipboard.setStringAsync(formatSensiText(values, tuning));
            successFeedback();
            Alert.alert('Copied', 'Open the game settings and enter these numbers.');
          }}
        />
      </Card>

      <SectionLabel>Launch</SectionLabel>
      <LaunchBar />
    </Screen>
  );
}
