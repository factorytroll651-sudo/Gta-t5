import { useMemo, useState } from 'react';
import { Alert, Platform, Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  Card,
  Chip,
  Field,
  FireButtonPreview,
  HudDiagram,
  NeonButton,
  RecoilGuide,
  Row,
  Screen,
  SectionLabel,
  SensiSlider,
  Title,
} from '@/components/ui';
import { LaunchBar } from '@/components/LaunchBar';
import { COLORS } from '@/constants/theme';
import { searchDevices } from '@/constants/devices';
import { OPTIMIZERS } from '@/constants/optimizers';
import { TIER_FEATURES } from '@/constants/pricing';
import { WEAPON_CATEGORIES, WEAPON_CATEGORY_LIST } from '@/constants/weapons';
import { findDevice, getScreenMetrics } from '@/services/device';
import { selectionTick, successFeedback, warnFeedback } from '@/services/feedback';
import { ALGORITHM_DISCLAIMER, DPI_STEPS } from '@/services/sensiAlgorithm';
import { useSensiStore } from '@/stores/useSensiStore';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';
import type { FingerLayout, PlayStyle, SensiValues, WeaponCategory } from '@/types';

const SLIDERS: { key: keyof SensiValues; label: string; hint: string }[] = [
  { key: 'general', label: 'Geral', hint: 'Base camera movement' },
  { key: 'redDot', label: 'Ponto Vermelho', hint: 'Iron-sight tracking speed' },
  { key: 'scope2x', label: 'Mira 2x', hint: 'Medium-range drag' },
  { key: 'scope4x', label: 'Mira 4x', hint: 'Long-range spray control' },
  { key: 'scopeAwm', label: 'Mira AWM', hint: 'Sniper crosshair stabilization' },
  { key: 'freeLook', label: 'Olhadinha', hint: '360-degree sprint camera' },
];

const STYLES: { id: PlayStyle; label: string }[] = [
  { id: 'rusher', label: 'Rusher' },
  { id: 'support', label: 'Support' },
  { id: 'sniper', label: 'Sniper' },
  { id: 'igl', label: 'IGL' },
];

const LAYOUTS: FingerLayout[] = [2, 3, 4];
const POINTER_NOTCHES = [-3, -2, -1, 0, 1, 2, 3];

export default function SensiScreen() {
  const tier = useUserStore((s) => s.vipTier);
  const features = TIER_FEATURES[tier];
  const scale = useSettingsStore((s) => s.scale);
  const deviceId = useSettingsStore((s) => s.deviceId);
  const deviceLabel = useSettingsStore((s) => s.deviceLabel);

  const values = useSensiStore((s) => s.values);
  const tuning = useSensiStore((s) => s.tuning);
  const weapon = useSensiStore((s) => s.weapon);
  const playStyle = useSensiStore((s) => s.playStyle);
  const optimizers = useSensiStore((s) => s.optimizers);
  const profiles = useSensiStore((s) => s.profiles);

  const [query, setQuery] = useState('');
  const [profileName, setProfileName] = useState('');
  const [openOptimizer, setOpenOptimizer] = useState<string | null>(null);

  const results = useMemo(() => (query.trim() ? searchDevices(query, 6) : []), [query]);
  const goPlans = (): void => router.push('/plans');

  const regenerate = (): void => {
    useSensiStore.getState().generate(findDevice(useSettingsStore.getState().deviceId), getScreenMetrics(), scale);
    successFeedback();
  };

  const setScale = (next: 100 | 200): void => {
    useSettingsStore.getState().setScale(next);
    if (next === 100) useSensiStore.getState().clampAll(100);
  };

  const pickWeapon = (id: WeaponCategory | null): void => {
    if (id && !features.weaponPresets) {
      warnFeedback();
      Alert.alert('Pro feature', 'Weapon-specific sensitivities are part of the Pro plan.', [
        { text: 'Not now', style: 'cancel' },
        { text: 'See plans', onPress: goPlans },
      ]);
      return;
    }
    useSensiStore.getState().setWeapon(id, scale);
  };

  const toggleOptimizer = (id: (typeof OPTIMIZERS)[number]['id']): void => {
    if (!features.regedit) {
      warnFeedback();
      Alert.alert('Pro feature', 'Regedit optimizer toggles are part of the Pro plan.', [
        { text: 'Not now', style: 'cancel' },
        { text: 'See plans', onPress: goPlans },
      ]);
      return;
    }
    selectionTick();
    useSensiStore.getState().toggleOptimizer(id);
    setOpenOptimizer((cur) => (cur === id ? null : id));
  };

  const onSave = (): void => {
    const name = profileName.trim();
    if (!name) {
      Alert.alert('Name your profile', 'Enter a name such as "Ranked setup".');
      return;
    }
    useSensiStore.getState().saveProfile(name, deviceLabel);
    setProfileName('');
    successFeedback();
  };

  const guideWeapon: WeaponCategory = weapon ?? 'rifle';

  return (
    <Screen>
      <Title>Sensi Generator</Title>

      <Card tone="green">
        <SectionLabel>Device</SectionLabel>
        <Text style={{ color: COLORS.text, fontSize: 17, fontWeight: '900' }}>{deviceLabel}</Text>
        <Field value={query} onChangeText={setQuery} placeholder="Search another model" />
        {results.map((d) => (
          <Pressable
            key={d.id}
            onPress={() => {
              selectionTick();
              useSettingsStore.getState().setDevice(d.id, d.model);
              setQuery('');
            }}
            style={{ paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border }}
          >
            <Text style={{ color: COLORS.text, fontWeight: '700' }}>{d.model}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              {d.screenInches}" · {d.refreshHz} Hz · {d.tier}
            </Text>
          </Pressable>
        ))}
        <SectionLabel>Play style</SectionLabel>
        <Row>
          {STYLES.map((s) => (
            <Chip
              key={s.id}
              label={s.label}
              active={s.id === playStyle}
              onPress={() => useSensiStore.getState().setPlayStyle(s.id)}
            />
          ))}
        </Row>
        <SectionLabel>Fingers</SectionLabel>
        <Row>
          {LAYOUTS.map((l) => (
            <Chip
              key={l}
              label={`${l}-finger`}
              active={l === tuning.fingerLayout}
              onPress={() => useSensiStore.getState().setFingerLayout(l)}
            />
          ))}
        </Row>
        <NeonButton title="Generate for my phone" icon="flash" onPress={regenerate} />
        <Text style={{ color: COLORS.muted, fontSize: 11 }}>{ALGORITHM_DISCLAIMER}</Text>
      </Card>

      <Card>
        <Row>
          <SectionLabel>Sensitivity</SectionLabel>
          <View style={{ marginLeft: 'auto', flexDirection: 'row', gap: 6 }}>
            <Chip label="0-100" active={scale === 100} onPress={() => setScale(100)} />
            <Chip label="0-200" active={scale === 200} onPress={() => setScale(200)} />
          </View>
        </Row>
        {SLIDERS.map((s) => (
          <SensiSlider
            key={s.key}
            label={s.label}
            hint={s.hint}
            value={values[s.key]}
            max={scale}
            onChange={(v) => useSensiStore.getState().setValue(s.key, v, scale)}
          />
        ))}
      </Card>

      <Card>
        <SectionLabel>Weapon presets</SectionLabel>
        <Row>
          <Chip label="Base" active={weapon === null} onPress={() => pickWeapon(null)} />
          {WEAPON_CATEGORY_LIST.map((w) => (
            <Chip
              key={w.id}
              label={w.label}
              active={weapon === w.id}
              locked={!features.weaponPresets}
              onPress={() => pickWeapon(w.id)}
            />
          ))}
        </Row>
        {weapon ? (
          <View style={{ gap: 4 }}>
            <Text style={{ color: COLORS.text, fontWeight: '700' }}>{WEAPON_CATEGORIES[weapon].weapons.join(' · ')}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 13 }}>{WEAPON_CATEGORIES[weapon].dragNote}</Text>
          </View>
        ) : null}
      </Card>

      <Card>
        <SectionLabel>Hardware tuning</SectionLabel>
        <Text style={{ color: COLORS.text, fontWeight: '800' }}>Tamanho do botão: {tuning.fireButtonSize}%</Text>
        <FireButtonPreview percent={tuning.fireButtonSize} />
        <SensiSlider
          label="Fire button size"
          hint="Percent of the default button"
          value={tuning.fireButtonSize}
          max={100}
          color={COLORS.red}
          onChange={(v) => useSensiStore.getState().setTuning({ fireButtonSize: Math.max(10, v) })}
        />
        <SectionLabel>Posição do botão</SectionLabel>
        <HudDiagram layout={tuning.fingerLayout} firePercent={tuning.fireButtonSize} />

        {Platform.OS === 'android' ? (
          <View style={{ gap: 6 }}>
            <SectionLabel>DPI recomendada</SectionLabel>
            <Row>
              {DPI_STEPS.map((d) => (
                <Chip
                  key={d}
                  label={String(d)}
                  active={d === tuning.recommendedDpi}
                  onPress={() => useSensiStore.getState().setTuning({ recommendedDpi: d })}
                />
              ))}
            </Row>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              Set it in Developer options → Minimum width (Smallest width). Changing DPI resizes everything on the
              phone, so note your original value first.
            </Text>
          </View>
        ) : null}

        <SectionLabel>Velocidade do ponteiro</SectionLabel>
        <Row gap={6}>
          {POINTER_NOTCHES.map((n) => (
            <Chip
              key={n}
              label={n > 0 ? `+${n}` : String(n)}
              active={n === tuning.pointerSpeed}
              onPress={() => useSensiStore.getState().setTuning({ pointerSpeed: n })}
            />
          ))}
        </Row>
      </Card>

      <Card>
        <SectionLabel>Tactical optimizer (Regedit)</SectionLabel>
        <Text style={{ color: COLORS.muted, fontSize: 12 }}>
          Guided checklists. They do not change any phone or game setting by themselves.
        </Text>
        {OPTIMIZERS.map((o) => {
          const on = optimizers[o.id];
          const open = on && openOptimizer === o.id;
          return (
            <View key={o.id} style={{ gap: 6, borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 10 }}>
              <Pressable onPress={() => toggleOptimizer(o.id)} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <MaterialCommunityIcons
                  name={on ? 'check-circle' : features.regedit ? 'circle-outline' : 'lock'}
                  size={22}
                  color={on ? COLORS.green : features.regedit ? COLORS.muted : COLORS.amber}
                />
                <View style={{ flex: 1 }}>
                  <Text style={{ color: COLORS.text, fontWeight: '800' }}>{o.title}</Text>
                  <Text style={{ color: COLORS.muted, fontSize: 12 }}>{o.subtitle}</Text>
                </View>
              </Pressable>
              {open ? (
                <View style={{ gap: 6, paddingLeft: 32 }}>
                  {o.steps.map((st) => (
                    <Text key={st} style={{ color: COLORS.muted, fontSize: 13 }}>
                      • {st}
                    </Text>
                  ))}
                  {o.id === 'semRecuo' ? <RecoilGuide weapon={guideWeapon} /> : null}
                </View>
              ) : null}
            </View>
          );
        })}
      </Card>

      <Card>
        <SectionLabel>Save profile</SectionLabel>
        <Field value={profileName} onChangeText={setProfileName} placeholder="Profile name" autoCapitalize="sentences" />
        <NeonButton title="Salvar como meu perfil" icon="check" onPress={onSave} />
        {profiles.map((p) => (
          <View
            key={p.id}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 8,
              borderTopWidth: 1,
              borderTopColor: COLORS.border,
              paddingTop: 10,
            }}
          >
            <Pressable
              onPress={() => {
                useSensiStore.getState().loadProfile(p.id);
                successFeedback();
              }}
              style={{ flex: 1 }}
            >
              <Text style={{ color: COLORS.text, fontWeight: '800' }}>{p.profileName}</Text>
              <Text style={{ color: COLORS.muted, fontSize: 12 }}>
                G{p.general} · RD{p.redDot} · {p.fireButtonSize}% · {p.phoneModel}
              </Text>
            </Pressable>
            <Pressable onPress={() => useSensiStore.getState().toggleFavorite(p.id)} hitSlop={8}>
              <MaterialCommunityIcons
                name={p.isFavorite ? 'heart' : 'heart-outline'}
                size={22}
                color={p.isFavorite ? COLORS.red : COLORS.muted}
              />
            </Pressable>
            <Pressable
              onPress={() =>
                Alert.alert('Delete profile?', p.profileName, [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Delete', style: 'destructive', onPress: () => useSensiStore.getState().deleteProfile(p.id) },
                ])
              }
              hitSlop={8}
            >
              <MaterialCommunityIcons name="trash-can-outline" size={22} color={COLORS.muted} />
            </Pressable>
          </View>
        ))}
      </Card>

      <SectionLabel>Launch</SectionLabel>
      <LaunchBar />
    </Screen>
  );
}
