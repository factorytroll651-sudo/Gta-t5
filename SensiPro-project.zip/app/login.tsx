import { useState } from 'react';
import { Alert, Text } from 'react-native';
import { router } from 'expo-router';
import { Card, Field, NeonButton, Screen, ScreenHeader } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { BackendError, sendOtp, syncUserMeta, verifyOtp } from '@/services/backend';
import { successFeedback } from '@/services/feedback';
import { isBackendConfigured } from '@/services/supabase';
import { useSettingsStore } from '@/stores/useSettingsStore';
import { useUserStore } from '@/stores/useUserStore';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  if (!isBackendConfigured) {
    return (
      <Screen bottomInset>
        <ScreenHeader title="Sign in" />
        <Card>
          <Text style={{ color: COLORS.text, fontWeight: '800' }}>Offline mode</Text>
          <Text className="text-muted">
            This build has no online account service, so everything is saved on this phone. Sign-in, cloud backup,
            referral and coupon codes need a build made with Supabase credentials.
          </Text>
          <NeonButton title="Continue offline" variant="dark" onPress={() => router.back()} />
        </Card>
      </Screen>
    );
  }

  const onSend = async (): Promise<void> => {
    const clean = email.trim().toLowerCase();
    if (!EMAIL_RE.test(clean)) {
      Alert.alert('Check your email', 'Enter a valid email address.');
      return;
    }
    setBusy(true);
    try {
      await sendOtp(clean);
      setEmail(clean);
      setSent(true);
    } catch (e) {
      Alert.alert('Could not send code', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  const onVerify = async (): Promise<void> => {
    const token = code.replace(/\s/g, '');
    if (!/^\d{6,8}$/.test(token)) {
      Alert.alert('Check the code', 'Enter the 6 to 8 digit code from the email.');
      return;
    }
    setBusy(true);
    try {
      const user = await verifyOtp(email, token);
      useUserStore.getState().setAuth(user.userId, user.email);
      const settings = useSettingsStore.getState();
      await syncUserMeta(user.userId, { phoneModel: settings.deviceLabel, game: settings.game }).catch(() => undefined);
      successFeedback();
      router.back();
    } catch (e) {
      Alert.alert('Could not verify', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen bottomInset>
      <ScreenHeader title="Sign in" subtitle="No password. We email you a one-time code." />
      <Card>
        <Field
          value={email}
          onChangeText={setEmail}
          placeholder="you@example.com"
          keyboardType="email-address"
          autoComplete="email"
          editable={!sent}
        />
        {sent ? (
          <>
            <Text className="text-muted">Code sent to {email}. Enter it below.</Text>
            <Field
              value={code}
              onChangeText={setCode}
              placeholder="123456"
              keyboardType="number-pad"
              maxLength={8}
            />
            <NeonButton title="Verify and sign in" onPress={() => void onVerify()} loading={busy} />
            <NeonButton
              title="Use a different email"
              variant="dark"
              onPress={() => {
                setSent(false);
                setCode('');
              }}
            />
          </>
        ) : (
          <NeonButton title="Send code" icon="email-outline" onPress={() => void onSend()} loading={busy} />
        )}
      </Card>
    </Screen>
  );
}
