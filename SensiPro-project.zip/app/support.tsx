import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Card, Field, NeonButton, Screen, ScreenHeader, SectionLabel } from '@/components/ui';
import { COLORS } from '@/constants/theme';
import { TIER_FEATURES } from '@/constants/pricing';
import { BackendError, submitTicket } from '@/services/backend';
import { successFeedback } from '@/services/feedback';
import { isBackendConfigured } from '@/services/supabase';
import { useUserStore } from '@/stores/useUserStore';

export default function SupportScreen() {
  const userId = useUserStore((s) => s.userId);
  const tier = useUserStore((s) => s.vipTier);
  const tickets = useUserStore((s) => s.tickets);

  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const online = isBackendConfigured && userId !== null;
  const priority = TIER_FEATURES[tier].prioritySupport;
  const queued = tickets.filter((t) => t.status === 'queued');

  const send = async (): Promise<void> => {
    const s = subject.trim();
    const m = message.trim();
    if (s.length < 3 || m.length < 10) {
      Alert.alert('Add more detail', 'Write a short subject and at least a sentence describing the problem.');
      return;
    }
    setBusy(true);
    try {
      const store = useUserStore.getState();
      if (online && userId) {
        await submitTicket(userId, s, m, priority);
        store.addTicket(s, m, 'sent');
        Alert.alert('Ticket sent', priority ? 'Priority support will reply by email.' : 'We will reply by email.');
      } else {
        store.addTicket(s, m, 'queued');
        Alert.alert('Saved on this phone', 'Sign in to send it. It stays in the list below until then.');
      }
      successFeedback();
      setSubject('');
      setMessage('');
    } catch (e) {
      Alert.alert('Could not send', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  const flushQueue = async (): Promise<void> => {
    if (!userId) return;
    setBusy(true);
    const sent: string[] = [];
    try {
      for (const t of queued) {
        await submitTicket(userId, t.subject, t.message, priority);
        sent.push(t.id);
      }
      Alert.alert('Sent', `${sent.length} queued ticket(s) sent.`);
    } catch (e) {
      Alert.alert('Could not send all', e instanceof BackendError ? e.message : 'Try again in a moment.');
    } finally {
      if (sent.length > 0) useUserStore.getState().markTicketsSent(sent);
      setBusy(false);
    }
  };

  return (
    <Screen bottomInset>
      <ScreenHeader
        title="Support"
        subtitle={priority ? 'Elite: your tickets are marked priority.' : 'Tell us what went wrong.'}
      />

      <Card>
        <Field value={subject} onChangeText={setSubject} placeholder="Subject" autoCapitalize="sentences" />
        <Field
          value={message}
          onChangeText={setMessage}
          placeholder="Describe the problem"
          autoCapitalize="sentences"
          multiline
          style={{ minHeight: 110, textAlignVertical: 'top' }}
        />
        <NeonButton title="Submit ticket" icon="email-outline" onPress={() => void send()} loading={busy} />
        {!online ? (
          <Text style={{ color: COLORS.amberLight, fontSize: 12 }}>
            {isBackendConfigured
              ? 'You are not signed in, so tickets are saved here until you sign in.'
              : 'This build has no online service, so tickets are only saved on this phone.'}
          </Text>
        ) : null}
        {isBackendConfigured && !online ? (
          <NeonButton title="Sign in" variant="dark" onPress={() => router.push('/login')} />
        ) : null}
        {online && queued.length > 0 ? (
          <NeonButton title={`Send ${queued.length} queued`} variant="dark" onPress={() => void flushQueue()} loading={busy} />
        ) : null}
      </Card>

      {tickets.length > 0 ? <SectionLabel>Your tickets</SectionLabel> : null}
      {tickets.map((t) => (
        <Card key={t.id}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: COLORS.text, fontWeight: '800', flexShrink: 1 }}>{t.subject}</Text>
            <Text style={{ color: t.status === 'sent' ? COLORS.greenLight : COLORS.amberLight, fontWeight: '800', fontSize: 12 }}>
              {t.status === 'sent' ? 'SENT' : 'QUEUED'}
            </Text>
          </View>
          <Text style={{ color: COLORS.muted, fontSize: 13 }}>{t.message}</Text>
        </Card>
      ))}
    </Screen>
  );
}
