import '../global.css';
import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { COLORS } from '@/constants/theme';
import { restoreSession } from '@/services/backend';
import { initPurchases, syncEntitlements } from '@/services/purchases';
import { supabase } from '@/services/supabase';
import { useStoresHydrated } from '@/stores/hydration';
import { useUserStore } from '@/stores/useUserStore';

export default function RootLayout() {
  const hydrated = useStoresHydrated();

  useEffect(() => {
    if (!hydrated) return undefined;
    let cancelled = false;

    const boot = async (): Promise<void> => {
      const billingReady = initPurchases();
      const session = await restoreSession().catch(() => null);
      if (cancelled) return;
      if (session) useUserStore.getState().setAuth(session.userId, session.email);

      if (billingReady) {
        const tier = await syncEntitlements();
        if (cancelled) return;
        const user = useUserStore.getState();
        if (tier) user.setVipTier(tier, 'store');
        else if (user.tierSource === 'store') user.setVipTier('free', 'none');
      }
    };
    void boot();

    const sub = supabase?.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_OUT') useUserStore.getState().clearAuth();
    });

    return () => {
      cancelled = true;
      sub?.data.subscription.unsubscribe();
    };
  }, [hydrated]);

  if (!hydrated) {
    return (
      <View style={{ flex: 1, backgroundColor: COLORS.bg, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={COLORS.green} size="large" />
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: COLORS.bg },
            animation: 'fade',
          }}
        >
          <Stack.Screen name="login" options={{ presentation: 'modal' }} />
        </Stack>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
