package com.fiveplay.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String TAG = "FivePlay";

    // ---------- CONFIG ----------
    private static final String APP_NAME = "GTA V Cloud by Siwoo";
    private static final String START_URL = "https://fiveplay.lol/";
    private static final String TELEGRAM_URL = "https://t.me/GTA_V_BY_Siwoo";
    // Main-page navigation outside these hosts is blocked (ad redirects). Add hosts if needed.
    private static final String[] ALLOWED_HOSTS = {"fiveplay.lol"};
    // Requests to these hosts are dropped when Ad Block is ON (panel switch, default OFF).
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "amazon-adsystem.com", "adsterra.com",
            "popads.net", "popcash.net", "propellerads.com", "propellerclick.com",
            "exoclick.com", "exosrv.com", "juicyads.com", "clickadu.com", "hilltopads.net",
            "monetag.com", "onclickads.net", "a-ads.com", "admaven.com", "ad-maven.com",
            "mgid.com", "taboola.com", "outbrain.com", "criteo.com", "pubmatic.com",
            "rubiconproject.com", "openx.net"};
    private static final boolean CONTROLS_ENABLED = true;
    // false = native key events (works inside iframes). true = JS KeyboardEvent dispatch.
    // If buttons do nothing in the game, flip this.
    private static final boolean USE_JS_KEYS = false;
    // Joystick: up, left, down, right
    private static final int[] STICK_KEYS = {
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D};
    // Buttons (max 4): bottom, right, left, top
    private static final String[] BTN_LABELS = {"A", "B", "X", "Y"};
    private static final int[] BTN_KEYS = {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_SHIFT_LEFT,
            KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_Q};
    // ----------------------------

    private static final String PREFS = "siwoo_prefs";
    private static final String PREF_GATE_DONE = "gate_done";
    private static final String PREF_ADBLOCK = "adblock";
    private static final long SPLASH_MIN_MS = 1500L;
    private static final long SPLASH_MAX_MS = 20000L;
    private static final int PANEL_WIDTH_DP = 230;
    private static final int PROGRESS_WIDTH_DP = 220;

    // Unicode escapes keep the source file pure ASCII.
    private static final String ICON_BOLT = "\u26A1";
    private static final String LABEL_RELOAD = "\uD83D\uDD04  Reload Game";
    private static final String LABEL_CACHE = "\uD83E\uDDF9  Cache Reset";
    private static final String LABEL_CACHE_SURE = "\u26A0  Pakka? Dobara dabao";
    private static final String LABEL_TELEGRAM = "\uD83D\uDCAC  Telegram Group";
    private static final String LABEL_STORAGE = "\u2699  Phone Storage Settings";
    private static final String LABEL_EXIT = "\u2716  Exit App";
    private static final String WARN = "\u26A0 ";

    private static final String ERROR_HTML =
            "<html><body style='background:#000;color:#fff;font-family:sans-serif;"
                    + "display:flex;flex-direction:column;align-items:center;"
                    + "justify-content:center;height:100vh;margin:0'>"
                    + "<h2>No connection</h2>"
                    + "<button style='font-size:20px;padding:12px 28px' "
                    + "onclick=\"location.href='" + START_URL + "'\">Retry</button>"
                    + "</body></html>";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private FrameLayout root;
    private WebView webView;
    private ControlOverlay overlay;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private long lastBackPress = 0L;

    // splash + Telegram gate
    private FrameLayout splash;
    private TextView splashStatus;
    private TextView splashWarn;
    private View progressFill;
    private LinearLayout gateBox;
    private Button continueBtn;
    private boolean splashShowing = true;
    private boolean gateRequired;
    private boolean joinOpened = false;
    private boolean pageReady = false;
    private long splashShownAt;
    private long splashWaitFrom;
    private int loadProgress = 0;

    // corner badge + booster panel
    private TextView badge;
    private TextView boosterHandle;
    private FrameLayout boosterPanel;
    private TextView statusText;
    private Button tileCache;
    private Button tileAd;
    private Button tileControls;
    private boolean panelOpen = false;
    private boolean cacheArmed = false;
    private boolean controlsOn = true;
    private volatile boolean adBlock = false;

    private final Runnable hideSplashNow = this::hideSplash;
    private final Runnable splashCheck = this::tryHideSplash;
    private final Runnable disarmCache = this::disarmCacheTile;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        adBlock = prefs.getBoolean(PREF_ADBLOCK, false);
        gateRequired = !prefs.getBoolean(PREF_GATE_DONE, false);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        enterImmersive();

        ViewGroup.LayoutParams match = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.setMotionEventSplittingEnabled(true);

        webView = new WebView(this);
        configureWebView(webView);
        root.addView(webView, match);

        if (CONTROLS_ENABLED) {
            overlay = new ControlOverlay(this, this::sendKey, STICK_KEYS, BTN_LABELS, BTN_KEYS);
            root.addView(overlay, match);
        }

        buildBadge();
        buildBooster();
        buildSplash();
        setContentView(root);

        // The game starts loading right now, behind the splash / Telegram popup.
        splashShownAt = SystemClock.uptimeMillis();
        splashWaitFrom = splashShownAt;
        handler.postDelayed(splashCheck, SPLASH_MAX_MS);
        refreshWarnings();
        updateSplashStatus();

        if (state == null || webView.restoreState(state) == null) {
            webView.loadUrl(START_URL);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        // Some sites refuse WebView clients ("; wv" in the user agent): present as plain Chrome.
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));

        // Keep the web renderer at high priority so Android does not starve or kill it.
        w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        w.setBackgroundColor(0xFF000000);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setLongClickable(false);
        w.setOnLongClickListener(v -> true);
        w.setHapticFeedbackEnabled(false);
        w.setFocusable(true);
        w.setFocusableInTouchMode(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new Client());
        w.setWebChromeClient(chromeClient);
    }

    // ---------- UI helpers ----------

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) {
            g.setStroke(dp(1), stroke);
        }
        return g;
    }

    private Button styledButton(String text, int fill, int stroke) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(roundRect(fill, stroke, 12));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private Button tile(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setBackground(roundRect(0x33FFFFFF, 0x55FFFFFF, 10));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        lp.topMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    // ---------- corner badge ----------

    private void buildBadge() {
        badge = new TextView(this);
        badge.setText(APP_NAME);
        badge.setTextColor(0xB3FFFFFF);
        badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        badge.setTypeface(null, Typeface.BOLD);
        badge.setShadowLayer(4f, 0f, 0f, 0xFF000000);
        badge.setClickable(false);
        badge.setFocusable(false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.LEFT);
        lp.leftMargin = dp(14);
        lp.topMargin = dp(8);
        root.addView(badge, lp);
    }

    // ---------- booster side panel ----------

    private void buildBooster() {
        boosterHandle = new TextView(this);
        boosterHandle.setText(ICON_BOLT);
        boosterHandle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f);
        boosterHandle.setTextColor(0xFFFFFFFF);
        boosterHandle.setGravity(Gravity.CENTER);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(0x88000000);
        dot.setStroke(dp(1), 0x99FFFFFF);
        boosterHandle.setBackground(dot);
        boosterHandle.setAlpha(0.8f);
        boosterHandle.setOnClickListener(v -> setPanelOpen(!panelOpen));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(
                dp(40), dp(40), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        hp.rightMargin = dp(8);
        root.addView(boosterHandle, hp);

        boosterPanel = new FrameLayout(this);
        boosterPanel.setBackground(roundRect(0xEE101018, 0x66FFFFFF, 14));
        boosterPanel.setClickable(true);
        boosterPanel.setVisibility(View.GONE);
        boosterPanel.setAlpha(0f);
        boosterPanel.setTranslationX(dp(PANEL_WIDTH_DP + 60));

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(10), dp(12), dp(12));

        TextView head = new TextView(this);
        head.setText(ICON_BOLT + " Game Booster");
        head.setTextColor(0xFFFFFFFF);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        head.setTypeface(null, Typeface.BOLD);
        col.addView(head);

        statusText = new TextView(this);
        statusText.setTextColor(0xCCFFFFFF);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(6);
        col.addView(statusText, stp);

        col.addView(tile(LABEL_RELOAD, v -> reloadGame()));
        tileCache = tile(LABEL_CACHE, v -> onCacheTile());
        col.addView(tileCache);
        tileAd = tile("", v -> toggleAdBlock());
        col.addView(tileAd);
        if (overlay != null) {
            tileControls = tile("", v -> toggleControls());
            col.addView(tileControls);
        }
        col.addView(tile(LABEL_TELEGRAM, v -> openTelegram()));
        col.addView(tile(LABEL_STORAGE, v -> openStorageSettings()));
        col.addView(tile(LABEL_EXIT, v -> finish()));
        updateTileLabels();

        scroll.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        boosterPanel.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                dp(PANEL_WIDTH_DP), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        pp.rightMargin = dp(56);
        pp.topMargin = dp(12);
        pp.bottomMargin = dp(12);
        root.addView(boosterPanel, pp);
    }

    private void setPanelOpen(boolean open) {
        panelOpen = open;
        if (open) {
            updateStatus();
            disarmCacheTile();
            boosterPanel.setVisibility(View.VISIBLE);
            boosterPanel.animate().translationX(0f).alpha(1f).setDuration(180L).start();
            boosterHandle.setAlpha(1f);
        } else {
            boosterPanel.animate().translationX(dp(PANEL_WIDTH_DP + 60)).alpha(0f)
                    .setDuration(160L)
                    .withEndAction(() -> {
                        if (!panelOpen) {
                            boosterPanel.setVisibility(View.GONE);
                        }
                    })
                    .start();
            boosterHandle.setAlpha(0.8f);
        }
    }

    private void updateTileLabels() {
        if (tileAd != null) {
            tileAd.setText("\uD83D\uDEE1  Ad Block: " + (adBlock ? "ON" : "OFF"));
        }
        if (tileControls != null) {
            tileControls.setText("\uD83C\uDFAE  Controls: " + (controlsOn ? "ON" : "OFF"));
        }
        if (tileCache != null && !cacheArmed) {
            tileCache.setText(LABEL_CACHE);
        }
    }

    private void updateStatus() {
        if (statusText != null) {
            statusText.setText(buildStatus());
        }
    }

    private void reloadGame() {
        WebView w = webView;
        if (w != null) {
            String u = w.getUrl();
            if (u == null || u.startsWith("data:") || u.equals("about:blank")) {
                w.loadUrl(START_URL);
            } else {
                w.reload();
            }
        }
        setPanelOpen(false);
    }

    private void onCacheTile() {
        if (!cacheArmed) {
            cacheArmed = true;
            tileCache.setText(LABEL_CACHE_SURE);
            handler.postDelayed(disarmCache, 4000L);
            return;
        }
        disarmCacheTile();
        WebView w = webView;
        if (w != null) {
            w.clearCache(true);
            w.loadUrl(START_URL);
        }
        Toast.makeText(this, "Cache clear ho gaya. Agli load thodi slow hogi.",
                Toast.LENGTH_LONG).show();
        setPanelOpen(false);
    }

    private void disarmCacheTile() {
        handler.removeCallbacks(disarmCache);
        cacheArmed = false;
        updateTileLabels();
    }

    private void toggleAdBlock() {
        adBlock = !adBlock;
        prefs.edit().putBoolean(PREF_ADBLOCK, adBlock).apply();
        updateTileLabels();
        Toast.makeText(this, adBlock ? "Ad block ON, game reload ho raha hai"
                : "Ad block OFF, game reload ho raha hai", Toast.LENGTH_SHORT).show();
        reloadGame();
    }

    private void toggleControls() {
        if (overlay == null) {
            return;
        }
        controlsOn = !controlsOn;
        if (!controlsOn) {
            overlay.releaseAllKeys();
        }
        overlay.setVisibility(controlsOn ? View.VISIBLE : View.GONE);
        updateTileLabels();
    }

    private void openTelegram() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)));
            joinOpened = true;
        } catch (RuntimeException ex) {
            Log.e(TAG, "Could not open Telegram link", ex);
            Toast.makeText(this, "Telegram ya browser nahi khula. Link: " + TELEGRAM_URL,
                    Toast.LENGTH_LONG).show();
            joinOpened = true;
            if (gateRequired) {
                enableContinue();
            }
        }
    }

    private void openStorageSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        } catch (RuntimeException ex) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (RuntimeException ex2) {
                Log.e(TAG, "Could not open settings", ex2);
            }
        }
    }

    // ---------- phone status ----------

    private String netName() {
        try {
            ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                return "?";
            }
            Network n = cm.getActiveNetwork();
            if (n == null) {
                return "Offline";
            }
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            if (c == null) {
                return "Offline";
            }
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "WiFi";
            }
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return "Mobile data";
            }
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                return "Ethernet";
            }
            return "Online";
        } catch (RuntimeException ex) {
            return "?";
        }
    }

    private boolean isPowerSave() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isPowerSaveMode();
        } catch (RuntimeException ex) {
            return false;
        }
    }

    /** Returns {availableBytes, totalBytes, lowMemoryFlag}; -1 values when unknown. */
    private long[] ramInfo() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                return new long[]{mi.availMem, mi.totalMem, mi.lowMemory ? 1L : 0L};
            }
        } catch (RuntimeException ex) {
            Log.w(TAG, "ramInfo failed", ex);
        }
        return new long[]{-1L, -1L, 0L};
    }

    private long freeStorage() {
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            return sf.getAvailableBytes();
        } catch (RuntimeException ex) {
            return -1L;
        }
    }

    private static String fmtGb(long bytes) {
        if (bytes < 0L) {
            return "?";
        }
        return String.format(Locale.US, "%.1f GB", bytes / 1073741824.0);
    }

    private String buildWarnings() {
        StringBuilder sb = new StringBuilder();
        if ("Offline".equals(netName())) {
            sb.append(WARN).append("Internet nahi hai\n");
        }
        if (isPowerSave()) {
            sb.append(WARN).append("Battery saver ON: game slow chal sakta hai\n");
        }
        long[] r = ramInfo();
        if (r[2] == 1L || (r[0] >= 0L && r[0] < 600L * 1024L * 1024L)) {
            sb.append(WARN).append("RAM kam hai: background apps band karo\n");
        }
        return sb.toString().trim();
    }

    private String buildStatus() {
        long[] r = ramInfo();
        StringBuilder sb = new StringBuilder();
        sb.append("RAM: ").append(fmtGb(r[0])).append(" free / ").append(fmtGb(r[1]));
        sb.append("\nStorage: ").append(fmtGb(freeStorage())).append(" free");
        sb.append("\nNet: ").append(netName());
        sb.append("\nBattery saver: ").append(isPowerSave() ? "ON" : "OFF");
        String w = buildWarnings();
        if (!w.isEmpty()) {
            sb.append("\n\n").append(w);
        }
        return sb.toString();
    }

    // ---------- splash + Telegram gate ----------

    private void buildSplash() {
        splash = new FrameLayout(this);
        splash.setBackgroundColor(0xFF0A0A10);
        splash.setClickable(true);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(24), dp(12), dp(24), dp(12));

        ImageView logo = new ImageView(this);
        logo.setImageDrawable(new LayerDrawable(new Drawable[]{
                getDrawable(R.drawable.ic_launcher_bg),
                getDrawable(R.drawable.ic_launcher_fg)}));
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        logo.setClipToOutline(true);
        col.addView(logo, new LinearLayout.LayoutParams(dp(76), dp(76)));

        TextView title = new TextView(this);
        title.setText(APP_NAME);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(8);
        col.addView(title, tp);

        splashStatus = new TextView(this);
        splashStatus.setTextColor(0xCCFFFFFF);
        splashStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        splashStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(4);
        col.addView(splashStatus, stp);

        FrameLayout track = new FrameLayout(this);
        track.setBackground(roundRect(0x33FFFFFF, 0, 3));
        progressFill = new View(this);
        progressFill.setBackground(roundRect(0xFFFF9800, 0, 3));
        track.addView(progressFill, new FrameLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(
                dp(PROGRESS_WIDTH_DP), dp(6));
        trp.topMargin = dp(8);
        col.addView(track, trp);

        splashWarn = new TextView(this);
        splashWarn.setTextColor(0xFFFFB74D);
        splashWarn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        splashWarn.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wp.topMargin = dp(8);
        col.addView(splashWarn, wp);

        gateBox = new LinearLayout(this);
        gateBox.setOrientation(LinearLayout.VERTICAL);
        gateBox.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView info = new TextView(this);
        info.setText("Game chalane se pehle hamara Telegram group join karo. "
                + "Join karke wapas aao, phir Continue dabao.");
        info.setTextColor(0xFFFFFFFF);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        info.setGravity(Gravity.CENTER);
        info.setMaxWidth(dp(360));
        gateBox.addView(info);

        Button join = styledButton("Telegram Group Join Karo", 0xFF229ED9, 0);
        join.setOnClickListener(v -> openTelegram());
        LinearLayout.LayoutParams jp = new LinearLayout.LayoutParams(dp(260), dp(44));
        jp.topMargin = dp(12);
        gateBox.addView(join, jp);

        continueBtn = styledButton("Pehle group join karo", 0x33FFFFFF, 0x66FFFFFF);
        continueBtn.setEnabled(false);
        continueBtn.setAlpha(0.5f);
        continueBtn.setOnClickListener(v -> onContinue());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(260), dp(44));
        cp.topMargin = dp(8);
        gateBox.addView(continueBtn, cp);

        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gp.topMargin = dp(14);
        col.addView(gateBox, gp);
        gateBox.setVisibility(gateRequired ? View.VISIBLE : View.GONE);

        sv.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        splash.addView(sv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(splash, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void refreshWarnings() {
        if (splashWarn == null) {
            return;
        }
        String w = buildWarnings();
        splashWarn.setText(w);
        splashWarn.setVisibility(w.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void updateSplashStatus() {
        if (splashStatus == null) {
            return;
        }
        String text;
        if (loadProgress >= 100) {
            text = gateRequired ? "Game taiyar hai \u2713" : "Game khul raha hai...";
        } else {
            text = (gateRequired ? "Game peeche load ho raha hai: " : "Game load ho raha hai: ")
                    + loadProgress + "%";
        }
        splashStatus.setText(text);
    }

    private void setSplashProgress(int p) {
        loadProgress = Math.max(0, Math.min(100, p));
        if (progressFill != null) {
            ViewGroup.LayoutParams lp = progressFill.getLayoutParams();
            lp.width = dp(PROGRESS_WIDTH_DP) * loadProgress / 100;
            progressFill.setLayoutParams(lp);
        }
        updateSplashStatus();
    }

    private void enableContinue() {
        if (continueBtn == null) {
            return;
        }
        continueBtn.setEnabled(true);
        continueBtn.setAlpha(1f);
        continueBtn.setText("Continue \u25B6");
    }

    private void onContinue() {
        if (!joinOpened) {
            return;
        }
        prefs.edit().putBoolean(PREF_GATE_DONE, true).apply();
        gateRequired = false;
        gateBox.setVisibility(View.GONE);
        splashWaitFrom = SystemClock.uptimeMillis();
        handler.removeCallbacks(splashCheck);
        handler.postDelayed(splashCheck, SPLASH_MAX_MS);
        updateSplashStatus();
        tryHideSplash();
    }

    private void tryHideSplash() {
        if (!splashShowing || gateRequired) {
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (!pageReady && now - splashWaitFrom < SPLASH_MAX_MS) {
            return;
        }
        long remaining = SPLASH_MIN_MS - (now - splashShownAt);
        handler.removeCallbacks(hideSplashNow);
        if (remaining > 0L) {
            handler.postDelayed(hideSplashNow, remaining);
        } else {
            hideSplash();
        }
    }

    private void hideSplash() {
        if (!splashShowing) {
            return;
        }
        splashShowing = false;
        handler.removeCallbacks(splashCheck);
        splash.animate().alpha(0f).setDuration(250L)
                .withEndAction(() -> splash.setVisibility(View.GONE))
                .start();
        if (webView != null) {
            webView.requestFocus();
        }
    }

    private void bringChromeToFront() {
        if (overlay != null) {
            overlay.bringToFront();
        }
        if (badge != null) {
            badge.bringToFront();
        }
        if (boosterHandle != null) {
            boosterHandle.bringToFront();
        }
        if (boosterPanel != null) {
            boosterPanel.bringToFront();
        }
        if (splash != null && splash.getVisibility() == View.VISIBLE) {
            splash.bringToFront();
        }
    }

    // ---------- web clients ----------

    private final WebChromeClient chromeClient = new WebChromeClient() {
        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCallback = cb;
            root.addView(view, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            bringChromeToFront();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) {
                return;
            }
            root.removeView(customView);
            customView = null;
            if (customCallback != null) {
                customCallback.onCustomViewHidden();
                customCallback = null;
            }
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            setSplashProgress(newProgress);
            if (newProgress >= 100) {
                pageReady = true;
                tryHideSplash();
            }
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            Log.d(TAG, "console: " + m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
            return true;
        }
    };

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (!r.isForMainFrame()) {
                return false;
            }
            Uri u = r.getUrl();
            String scheme = u.getScheme();
            if (!"http".equals(scheme) && !"https".equals(scheme)) {
                Log.w(TAG, "Blocked non-web scheme: " + u);
                return true;
            }
            if (isAllowedHost(u.getHost())) {
                return false;
            }
            Log.w(TAG, "Blocked redirect: " + u);
            Toast.makeText(MainActivity.this, "Blocked redirect", Toast.LENGTH_SHORT).show();
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            if (adBlock && isAdHost(r.getUrl().getHost())) {
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            v.requestFocus();
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError err) {
            if (r.isForMainFrame()) {
                Log.e(TAG, "Load error " + err.getErrorCode() + ": " + err.getDescription());
                v.loadDataWithBaseURL(null, ERROR_HTML, "text/html", "UTF-8", null);
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            Log.e(TAG, "Renderer gone, crashed=" + d.didCrash() + ". Restarting.");
            Intent again = getIntent();
            if (root != null) {
                root.removeView(v);
            }
            v.destroy();
            webView = null;
            finish();
            startActivity(again);
            return true;
        }
    }

    private static boolean isAllowedHost(String host) {
        return hostMatches(host, ALLOWED_HOSTS);
    }

    private static boolean isAdHost(String host) {
        return hostMatches(host, AD_HOSTS);
    }

    private static boolean hostMatches(String host, String[] list) {
        if (host == null) {
            return false;
        }
        String h = host.toLowerCase(Locale.ROOT);
        for (String a : list) {
            if (h.equals(a) || h.endsWith("." + a)) {
                return true;
            }
        }
        return false;
    }

    // ---------- key injection ----------

    private void sendKey(int keyCode, boolean down) {
        WebView w = webView;
        if (w == null) {
            return;
        }
        try {
            if (down && !w.hasFocus()) {
                w.requestFocus();
            }
            if (USE_JS_KEYS) {
                sendJsKey(w, keyCode, down);
            } else {
                long now = SystemClock.uptimeMillis();
                w.dispatchKeyEvent(new KeyEvent(now, now,
                        down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP, keyCode, 0));
            }
        } catch (RuntimeException ex) {
            Log.e(TAG, "sendKey failed for keyCode " + keyCode, ex);
        }
    }

    private void sendJsKey(WebView w, int keyCode, boolean down) {
        String[] info = jsInfo(keyCode);
        if (info == null) {
            Log.w(TAG, "No JS mapping for keyCode " + keyCode);
            return;
        }
        String type = down ? "keydown" : "keyup";
        String js = "(function(){"
                + "var k=" + q(info[0]) + ",c=" + q(info[1]) + ",kc=" + info[2] + ";"
                + "var t=document.activeElement;"
                + "if(!t||t===document.body){t=document.querySelector('canvas')||document;}"
                + "var e=new KeyboardEvent('" + type + "',"
                + "{key:k,code:c,keyCode:kc,which:kc,bubbles:true,cancelable:true});"
                + "try{Object.defineProperty(e,'keyCode',{get:function(){return kc;}});"
                + "Object.defineProperty(e,'which',{get:function(){return kc;}});}catch(x){}"
                + "t.dispatchEvent(e);})();";
        w.evaluateJavascript(js, null);
    }

    private static String q(String s) {
        return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    /** Returns {key, code, jsKeyCode} or null if unmapped. */
    private static String[] jsInfo(int k) {
        if (k >= KeyEvent.KEYCODE_A && k <= KeyEvent.KEYCODE_Z) {
            int off = k - KeyEvent.KEYCODE_A;
            char c = (char) ('a' + off);
            return new String[]{String.valueOf(c), "Key" + Character.toUpperCase(c),
                    String.valueOf(65 + off)};
        }
        if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) {
            int off = k - KeyEvent.KEYCODE_0;
            return new String[]{String.valueOf(off), "Digit" + off, String.valueOf(48 + off)};
        }
        switch (k) {
            case KeyEvent.KEYCODE_SPACE:
                return new String[]{" ", "Space", "32"};
            case KeyEvent.KEYCODE_ENTER:
                return new String[]{"Enter", "Enter", "13"};
            case KeyEvent.KEYCODE_ESCAPE:
                return new String[]{"Escape", "Escape", "27"};
            case KeyEvent.KEYCODE_TAB:
                return new String[]{"Tab", "Tab", "9"};
            case KeyEvent.KEYCODE_SHIFT_LEFT:
                return new String[]{"Shift", "ShiftLeft", "16"};
            case KeyEvent.KEYCODE_CTRL_LEFT:
                return new String[]{"Control", "ControlLeft", "17"};
            case KeyEvent.KEYCODE_DPAD_LEFT:
                return new String[]{"ArrowLeft", "ArrowLeft", "37"};
            case KeyEvent.KEYCODE_DPAD_UP:
                return new String[]{"ArrowUp", "ArrowUp", "38"};
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                return new String[]{"ArrowRight", "ArrowRight", "39"};
            case KeyEvent.KEYCODE_DPAD_DOWN:
                return new String[]{"ArrowDown", "ArrowDown", "40"};
            default:
                return null;
        }
    }

    // ---------- lifecycle ----------

    @SuppressWarnings("deprecation")
    private void enterImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersive();
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) {
            chromeClient.onHideCustomView();
            return;
        }
        if (panelOpen) {
            setPanelOpen(false);
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackPress < 2000L) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (webView != null) {
            webView.saveState(out);
        }
    }

    @Override
    protected void onPause() {
        // While the Telegram popup is up the game keeps loading in the background.
        if (webView != null && !gateRequired) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
        if (gateRequired && joinOpened) {
            enableContinue();
        }
        refreshWarnings();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
