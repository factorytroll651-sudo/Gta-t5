package com.fiveplay.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class ControlOverlay extends View {

    public interface KeyListener {
        void onKey(int keyCode, boolean down);
    }

    private static final class Btn {
        final String label;
        final int keyCode;
        float cx, cy, r;
        int pointerId = -1;

        Btn(String label, int keyCode) {
            this.label = label;
            this.keyCode = keyCode;
        }

        boolean hit(float x, float y) {
            float dx = x - cx, dy = y - cy, rr = r * 1.25f;
            return dx * dx + dy * dy <= rr * rr;
        }
    }

    // Diamond layout: bottom, right, left, top
    private static final float[] OFF_X = {0f, 1f, -1f, 0f};
    private static final float[] OFF_Y = {1f, 0f, 0f, -1f};

    private final KeyListener listener;
    private final int[] stickKeys; // up, left, down, right
    private final boolean[] stickDown = new boolean[4];
    private final List<Btn> buttons = new ArrayList<>();
    private final float density;
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float stickCx, stickCy, stickR, thumbX, thumbY;
    private int stickPointer = -1;
    private float toggleCx, toggleCy, toggleR;
    private boolean hidden = false;

    public ControlOverlay(Context ctx, KeyListener listener, int[] stickKeys,
                          String[] labels, int[] keys) {
        super(ctx);
        if (listener == null) {
            throw new IllegalArgumentException("listener is null");
        }
        if (stickKeys == null || stickKeys.length != 4) {
            throw new IllegalArgumentException("stickKeys needs 4 keys: up, left, down, right");
        }
        if (labels == null || keys == null || labels.length != keys.length || labels.length > 4) {
            throw new IllegalArgumentException("labels/keys must match and hold at most 4 entries");
        }
        this.listener = listener;
        this.stickKeys = stickKeys.clone();
        this.density = ctx.getResources().getDisplayMetrics().density;
        for (int i = 0; i < labels.length; i++) {
            buttons.add(new Btn(labels[i], keys[i]));
        }
        fillPaint.setStyle(Paint.Style.FILL);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(2f * density);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(20f * density);
        textPaint.setFakeBoldText(true);
        setFocusable(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float d = density;
        stickR = 62f * d;
        stickCx = 36f * d + stickR;
        stickCy = h - 28f * d - stickR;
        thumbX = stickCx;
        thumbY = stickCy;

        float br = 30f * d;
        float spacing = 40f * d;
        float clusterCx = w - 36f * d - spacing - br;
        float clusterCy = h - 28f * d - spacing - br;
        for (int i = 0; i < buttons.size(); i++) {
            Btn b = buttons.get(i);
            b.r = br;
            b.cx = clusterCx + OFF_X[i] * spacing;
            b.cy = clusterCy + OFF_Y[i] * spacing;
        }

        toggleR = 16f * d;
        toggleCx = w - 28f * d;
        toggleCy = 28f * d;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!hidden) {
            fillPaint.setColor(0x33FFFFFF);
            c.drawCircle(stickCx, stickCy, stickR, fillPaint);
            strokePaint.setColor(0x99FFFFFF);
            c.drawCircle(stickCx, stickCy, stickR, strokePaint);
            fillPaint.setColor(0x88FFFFFF);
            c.drawCircle(thumbX, thumbY, stickR * 0.42f, fillPaint);

            for (Btn b : buttons) {
                boolean on = b.pointerId != -1;
                fillPaint.setColor(on ? 0xAAFFFFFF : 0x33FFFFFF);
                c.drawCircle(b.cx, b.cy, b.r, fillPaint);
                strokePaint.setColor(0x99FFFFFF);
                c.drawCircle(b.cx, b.cy, b.r, strokePaint);
                textPaint.setColor(on ? 0xFF000000 : 0xDDFFFFFF);
                drawCentered(c, b.label, b.cx, b.cy);
            }
        }
        fillPaint.setColor(0x44FFFFFF);
        c.drawCircle(toggleCx, toggleCy, toggleR, fillPaint);
        textPaint.setColor(0xDDFFFFFF);
        drawCentered(c, hidden ? "+" : "-", toggleCx, toggleCy);
    }

    private void drawCentered(Canvas c, String t, float x, float y) {
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        c.drawText(t, x, y - (fm.ascent + fm.descent) / 2f, textPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                float x = e.getX(idx);
                float y = e.getY(idx);
                int id = e.getPointerId(idx);

                float tx = x - toggleCx, ty = y - toggleCy, tr = toggleR * 1.6f;
                if (tx * tx + ty * ty <= tr * tr) {
                    setHidden(!hidden);
                    return true;
                }
                if (hidden) {
                    return false;
                }
                float sx = x - stickCx, sy = y - stickCy, sr = stickR * 1.35f;
                if (stickPointer == -1 && sx * sx + sy * sy <= sr * sr) {
                    stickPointer = id;
                    moveStick(x, y);
                    return true;
                }
                for (Btn b : buttons) {
                    if (b.pointerId == -1 && b.hit(x, y)) {
                        b.pointerId = id;
                        listener.onKey(b.keyCode, true);
                        invalidate();
                        return true;
                    }
                }
                return false; // not ours: let the game below receive this touch
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    if (e.getPointerId(i) == stickPointer) {
                        moveStick(e.getX(i), e.getY(i));
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                release(e.getPointerId(idx));
                return true;
            case MotionEvent.ACTION_CANCEL:
                releaseAll();
                return true;
            default:
                return false;
        }
    }

    private void moveStick(float x, float y) {
        float dx = x - stickCx;
        float dy = y - stickCy;
        float dist = (float) Math.hypot(dx, dy);
        if (dist > stickR) {
            dx = dx / dist * stickR;
            dy = dy / dist * stickR;
        }
        thumbX = stickCx + dx;
        thumbY = stickCy + dy;
        float t = 0.38f * stickR;
        setStick(0, dy < -t);
        setStick(1, dx < -t);
        setStick(2, dy > t);
        setStick(3, dx > t);
        invalidate();
    }

    private void setStick(int i, boolean down) {
        if (stickDown[i] != down) {
            stickDown[i] = down;
            listener.onKey(stickKeys[i], down);
        }
    }

    private void resetStick() {
        thumbX = stickCx;
        thumbY = stickCy;
        for (int i = 0; i < 4; i++) {
            setStick(i, false);
        }
    }

    private void release(int id) {
        if (id == stickPointer) {
            stickPointer = -1;
            resetStick();
        }
        for (Btn b : buttons) {
            if (b.pointerId == id) {
                b.pointerId = -1;
                listener.onKey(b.keyCode, false);
            }
        }
        invalidate();
    }

    private void releaseAll() {
        stickPointer = -1;
        resetStick();
        for (Btn b : buttons) {
            if (b.pointerId != -1) {
                b.pointerId = -1;
                listener.onKey(b.keyCode, false);
            }
        }
        invalidate();
    }

    /** Releases every held key; used when the controls are switched off from the booster panel. */
    public void releaseAllKeys() {
        releaseAll();
    }

    private void setHidden(boolean h) {
        hidden = h;
        if (h) {
            releaseAll();
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        releaseAll();
        super.onDetachedFromWindow();
    }
}
